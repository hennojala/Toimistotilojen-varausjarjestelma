﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static WpfApp1.MainWindow;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for CustomerEditWindow.xaml
    /// </summary>
    public partial class CustomerEdit : Window
    {        
        public CustomerEdit(Customer customer)
        {
            InitializeComponent();
            this.DataContext = customer;
        }

        private void saveButton_Click(object sender, RoutedEventArgs e)
        {
            int postcode;
            // You can change/add what characters are allowed in each type of textbox
            string patternPhoneNumber = @"^[0-9\+]+$";
            string patternNames = @"^[a-zA-ZäöüÄÖÜÅå\s\-]+$";
            string patternAddress = @"^[a-zA-ZäöüÄÖÜÅå\0-9\s\-\.,\/\\]+$";
            // Get the client entity from the DataContext.
            Customer customer = (Customer)this.DataContext;

            // Check if any of the required textboxes are empty
            if (string.IsNullOrEmpty(customer.Firstname) || string.IsNullOrEmpty(customer.Lastname) || string.IsNullOrEmpty(customer.Phone) || string.IsNullOrEmpty(customer.Address) || string.IsNullOrEmpty(customer.Postcode) || string.IsNullOrEmpty(customer.City))
            {
                MessageBox.Show("Täytä kaikki vaaditut kentät.", "Virhe");
                return;
            }

            // Check if the postcode textbox contains only numbers            
            if (!int.TryParse(postcodeTextBox.Text, out postcode))
            {
                MessageBox.Show("Postinumero voi sisältää vain numeroita.", "Virhe");
                return;
            }

            // Regular expression pattern that matches only digits and the + character            
            if (!Regex.IsMatch(phoneTextBox.Text, patternPhoneNumber))
            {
                MessageBox.Show("Puhelinnumero voi sisältää vain numeroita ja + merkin.", "Virhe");
                return;
            }

            // Check if the input matches the pattern
            if (!Regex.IsMatch(lastNameTextBox.Text, patternNames) || !Regex.IsMatch(firstNameTextBox.Text, patternNames) || !Regex.IsMatch(cityTextBox.Text, patternNames))
            {
                MessageBox.Show("Nimille ja paikkakunnalle sallitut merkit ovat kirjaimet, välilyönnit, ääkköset, väliviivat ja Å-merkki.", "Virhe");
                return;
            }
            // Check if the input matches the pattern
            if (!Regex.IsMatch(addressTextBox.Text, patternAddress))
            {
                MessageBox.Show("Osoite voi sisältää vain kirjaimia, numeroita ja joitain tyypillisiä erikoismerkkejä", "Virhe");
                return;
            }

            // A new Management Tools object is created.
            var tool = new Repository();

            // Let's call the method of the Management Tools object that updates customer data.
            tool.DBUpdateCustomer(customer);

            // A notification is displayed that the customer information has been updated.
            MessageBox.Show("Asiakastieto päivitetty!");

            // Let's set DialogResult to true so that the user interface knows that the operation has been completed.
            DialogResult = true;
        }


        // close window
        private void closeButton(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
