﻿using System;
using System.Collections.ObjectModel;
using static WpfApp1.MainWindow;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for BillManagement.xaml
    /// </summary>
    /// 


    public class Bill
    {
        public int BillID { get; set; }
        public DateTime Date { get; set; }
        public DateTime DueDate { get; set; }
        public string Description { get; set; }
        public Customer CustomerInfo { get; set; }

        public ObservableCollection<BillLine> BillLines { get; set; }

        public float RoomSum { get; set; }
        public float BillSum { get; set; }
        public Room Room { get; set; }
        public Service Service { get; set; }
        public int RoomID { get; set; }

        public string Info
        {
            get
            {
                return $"LaskuID: {BillID}           Lisäpalvelut: {BillLines.Count}\n" +
                    $"Lasku luotu: {Date}, Eräpäivä: {DueDate}\n" +
                    $"Vuokratila: {Room.Roomname} HuoneID: {Room.RoomID}\n" +
                    $"Varausaika: {Room.ReservationStarts.Date.ToShortDateString()}  -  {Room.ReservationEnds.Date.ToShortDateString()}\n" +
                    $"----------------------------------------------------------------";
            }
        }

        public Bill()
        {
            BillID = -1;
            Date = System.DateTime.Today.Date;
            DueDate = DateTime.Today.AddDays(14);
            Description = string.Empty;
            CustomerInfo = new Customer();
            BillLines = new ObservableCollection<BillLine>();
            Room = new Room();
            RoomSum = 0;
            BillSum = 0;
            RoomID = 0;
            

        }
       

    }


}
   
