﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Runtime.Intrinsics.X86;
using System.Security.Cryptography.Pkcs;
using System.Text;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Shapes;
using System.Xml.Linq;
using static WpfApp1.MainWindow;

namespace WpfApp1
{

    public class Repository
    {
        //Add your connect's data for this
        private const string local = @"Server=""; Port=""; User ID=""; Pwd="";";
        private const string localWithDb = @"Server=""; Port=""; User ID=""; Pwd=""; Database=OhjelmistoKehitysDB;";

        /// <summary>
        /// Remove OhjelmistoKehitysDB if exist and create a new one
        /// </summary>
        /// 

        public void CreateDb()
        {

            using (MySqlConnection conn = new MySqlConnection(local))
            {
                conn.Open();


                MySqlCommand cmd = new MySqlCommand("DROP DATABASE IF EXISTS OhjelmistoKehitysDB", conn);
                cmd.ExecuteNonQuery();

                cmd = new MySqlCommand("CREATE DATABASE OhjelmistoKehitysDB", conn);
                cmd.ExecuteNonQuery();
            }
        }
        /// <summary>
        /// Create Tables
        /// </summary>
        public void CreateTables()
        {
            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                string createTables = "" +
                    "Create Table Laskuttaja (" +
                    "Name VARCHAR(50) NOT NULL," +
                    "BankID VARCHAR(50));" +
                    "" +
                    "CREATE TABLE Customer\r\n(\r\n  " +
                    "CustomerID INT NOT NULL Auto_increment,\r\n  " +
                    "Lastname VARCHAR(50) NOT NULL,\r\n  " +
                    "Firstname VARCHAR(50) NOT NULL,\r\n  " +
                    "Phone VARCHAR(30) NOT NULL,\r\n  " +
                    "Address VARCHAR(50) NOT NULL,\r\n  " +
                    "Postcode VARCHAR(30) NOT NULL,\r\n  " +
                    "City VARCHAR(30) NOT NULL,\r\n\r\n  " +
                    "PRIMARY KEY (CustomerID)\r\n);" +
                    "" +
                    "CREATE TABLE Room\r\n(\r\n  " +
                    "RoomID INT NOT NULL Auto_increment,\r\n  " +
                    "Roomname VARCHAR(50) NOT NULL,\r\n  " +
                    "RoomSize VARCHAR(20) NOT NULL," +
                    "PriceForADay FLOAT," +
                    "Address VARCHAR(50) NOT NULL,\r\n  " +
                    "Postcode VARCHAR(50) NOT NULL,\r\n  " +
                    "City VARCHAR(50) NOT NULL,\r\n  " +
                    "PRIMARY KEY (RoomID)\r\n);" +
                    "" +
                    "CREATE TABLE Bill\r\n(\r\n  " +
                    "BillID INT NOT NULL Auto_increment,\r\n  " +
                    "Date DATE NOT NULL,\r\n  " +
                    "DueDate DATE NOT NULL,\r\n  " +
                    "ReservationStarts DATE," +
                    "ReservationEnds DATE," +
                    "CustomerID INT NOT NULL,\r\n  " +
                    "RoomID INT NOT NULL," +
                    "Description VARCHAR(800) NOT NULL,\r\n  " +
                    "PRIMARY KEY (BillID),\r\n  " +
                    "FOREIGN KEY (RoomID) REFERENCES Room(RoomID)," +
                    "FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID)\r\n);" +
                    "" +
                    "CREATE TABLE Service\r\n(\r\n  " +
                    "ServiceID INT NOT NULL Auto_increment,\r\n  " +
                    "ServiceName VARCHAR(50) NOT NULL,\r\n  " +
                    "Unit VARCHAR(20) NOT NULL," +
                    "UnitPrice FLOAT NOT NULL," +
                    "RoomID INT NOT NULL,\r\n  " +
                    "PRIMARY KEY (ServiceID),\r\n  " +
                    "FOREIGN KEY (RoomID) " +
                    "REFERENCES Room(RoomID)\r\n);" +
                    "" +
                    "CREATE TABLE Billline\r\n(\r\n  " +
                    "LineID INT NOT NULL Auto_increment," +
                    "Name VARCHAR(50), " +
                    "Unit VARCHAR(20),\r\n  " +
                    "UnitPrice FLOAT,\r\n  " +
                    "Amount INT NOT NULL,\r\n  " +

                    "ServiceID INT NOT NULL," +
                    "RoomID INT NOT NULL," +
                    "BillID INT NOT NULL," +
                    "" +
                    "PRIMARY KEY (LineID),\r\n  " +
                    "FOREIGN KEY (BillID) " +
                    "REFERENCES Bill(BillID),\r\n  " +
                    "FOREIGN KEY (RoomID) " +
                    "REFERENCES Room(RoomID),\r\n " +
                    "FOREIGN KEY (ServiceID) " +
                    "REFERENCES Service(ServiceID)\r\n);";



                MySqlCommand cmd = new MySqlCommand(createTables, conn);
                cmd.ExecuteNonQuery();
            }
        }
        /// <summary>
        /// Create examplary data
        /// </summary>
        public void CreateInitialData()
        {
            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                string createInitialData = "" +
                    "INSERT INTO laskuttaja (Name, BankID) Values ('Vuokratoimisto Oy', 'FI38372277373784');" +
                    "" +
                    "INSERT INTO room\r\n\t" +
                    "(Roomname, PriceForADay, RoomSize, Address, Postcode, City)\r\n\t" +
                    "VALUES ('VuokraLuukut Oy', 59, '120', 'osoitekuja 4', '00900', 'Helsinki');\t\r\n" +
                    "" +
                    "INSERT INTO room " +
                    "(Roomname, PriceForADay, RoomSize, Address, Postcode, City)" +
                    "VALUES ('Esimerkki Oy', 79, '110', 'osoitekuja 3', '00900', 'Helsinki');" +
                    "" +
                    "" +
                    "INSERT INTO room\r\n\t" +
                    "(Roomname, PriceForADay, RoomSize, Address, Postcode, City)\r\n\t" +
                    "VALUES ('HuoneetVuokralla Oy', 49, '85', 'osoitekuja 2', '00960', 'Helsinki');\t\r\n" +
                    "INSERT INTO customer\r\n\t" +
                    "(Lastname, Firstname, Phone, Address, Postcode, City)\r\n\t" +
                    "VALUES ('Esimerkki', 'Esim', '04513334554', 'katukuja4B', '00989', 'Helsinki');\r\n" +
                    "INSERT INTO customer\r\n\t" +
                    "(Lastname, Firstname, Phone, Address, Postcode, City)\r\n\t" +
                    "VALUES ('Pekkanen', 'Pekka', '0451344554', 'katukuja8B', '009860', 'Helsinki');\r\n" +
                    "" +
                    "" +
                    "" +
                    "INSERT INTO service\r\n\t" +
                    "(ServiceName, Unit, UnitPrice, RoomID)" +

                    "VALUES ('Aamupala 10 hengelle', 'Palvelu', 99, 1);\r\n" +
                    "" +                 

                    "VALUES ('Ruuan tarjoilu (10hengelle)', 'Palvelu', 99, 1);\r\n" +
                    "" +
                    "INSERT INTO service" +
                    "(ServiceName, Unit, UnitPrice, RoomID)" +
                    "VALUES ('Ruuan tarjoilu (10hengelle)', 'Palvelu', 99, 2);" +
                    "" +
                    "" +                   
                    "INSERT INTO service" +
                    "(ServiceName, Unit, UnitPrice, RoomID)" +
                    "VALUES ('Valkotaulu', 'Tuotevuokra', 39, 2);" +
                    "VALUES ('Videotykki', 'Tuotevuokra', 39, 1);\r\n" +
                    "" +
                    "INSERT INTO service" +
                    "(ServiceName, Unit, UnitPrice, RoomID)" +
                    "VALUES ('Videotykki', 'Tuotevuokra', 39, 2);" +
                    "" +
                    "INSERT INTO service" +
                    "(ServiceName, Unit, UnitPrice, RoomID)" +
                    "VALUES ('Siivous', 'Palvelu', 45.50, 1);" +
                    "" +
                    "INSERT INTO service" +
                    "(ServiceName, Unit, UnitPrice, RoomID)" +
                    "VALUES ('Tietokone', 'Tuotevuokra', 12.80, 2);" +
                    "" +
                    "INSERT INTO bill\r\n\t" +
                    "(Date, DueDate, CustomerID, RoomID, ReservationStarts, ReservationEnds, Description)\r\n\t" +
                    "VALUES (NOW(), DATE_ADD(CURDATE(), INTERVAL 2 WEEK), 1, 1, '2023-05-10', '2023-05-15', 'toimitilan ja varauksen tietoja');\r\n" +
                    "" +
                    "INSERT INTO billline\r\n\t" +
                    "(Name, Unit, Unitprice, Amount, BillID, RoomID, ServiceID)\r\n\t" +
                    "VALUES ('Aamupala 10 hengelle', 'Palvelu', 129, 2, 1, 1, 1);\r\n\t\r\n" +
                    "" +
                    "INSERT INTO billline\r\n\t" +
                    "(Name, Unit, Unitprice, Amount, BillID, RoomID, ServiceID)\r\n\t" +
                    "VALUES ('Videotykki', 'Tuotevuokra',  39, 1, 1, 1, 3);" +
                    "" +
                    "" +
                    "" +
                    "" +
                    " INSERT INTO bill " +
                    "(Date, DueDate, CustomerID, RoomID, ReservationStarts, ReservationEnds, Description) " +
                    "VALUES (NOW(), DATE_ADD(CURDATE(), INTERVAL 2 WEEK), 2, 2, '2023-04-01', '2023-04-05', 'toimitilan ja varauksen tietoja'); " +
                    "           " +
                    "INSERT INTO billline" +
                    "(Name, Unit, Unitprice, Amount, BillID, RoomID, ServiceID)" +
                    "VALUES ('Aamupala 10 hengelle', 'Palvelu', 129, 2, 2, 2, 1);" +
                    "VALUES ('Ruuan tarjoilu (10hengelle)', 'Palvelu', 129, 2, 2, 2, 2);" +
                    "" +
                    "INSERT INTO billline " +
                    "(Name, Unit, Unitprice, Amount, BillID, RoomID, ServiceID) " +
                    "VALUES ('Videotykki', 'Tuotevuokra',  39, 2, 2, 2, 4);" +
                    "" +
                    "" +
                    " INSERT INTO bill" +
                    "(Date, DueDate, CustomerID, RoomID, ReservationStarts, ReservationEnds, Description)" +
                    "VALUES (NOW(), DATE_ADD(CURDATE(), INTERVAL 2 WEEK), 1, 1, '2023-03-01', '2023-03-02', 'toimitilan ja varauksen tietoja');" +
                    "";

                MySqlCommand cmd = new MySqlCommand(createInitialData, conn);
                cmd.ExecuteNonQuery();

            }

        }

        //Customer - methods:

        /// <summary>
        /// The method searches all customers from the database and returns customers.
        /// </summary>
        public ObservableCollection<Customer> DBSearchAllCustomers()
        {
            var customers = new ObservableCollection<Customer>();

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                //Komento SQL:lle
                MySqlCommand cmd = new MySqlCommand("SELECT CustomerID, Lastname, Firstname, Phone, Address, Postcode, City FROM customer", conn);

                var dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    customers.Add(new Customer
                    {
                        CustomerID = dr.GetInt32("CustomerID"),
                        Lastname = dr.GetString("Lastname"),
                        Firstname = dr.GetString("Firstname"),
                        Phone = dr.GetString("Phone"),
                        Address = dr.GetString("Address"),
                        Postcode = dr.GetString("Postcode"),
                        City = dr.GetString("City")

                    });
                }
            }

            return customers;
        }

        /// <summary>
        /// The method searches customers one customer based on the Customer ID.
        /// </summary>
        /// <param name="customerid"></param>
        /// <returns></returns>
        public Customer DBSearchCustomerWithCustomerID(int customerid)
        {
            Customer custom = null;

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                //Komento SQL:lle
                MySqlCommand cmd = new MySqlCommand("SELECT CustomerID, Lastname, Firstname, Phone, Address, Postcode, City FROM Customer WHERE CustomerID=@customerID", conn);
                cmd.Parameters.AddWithValue("@customerID", customerid);

                var dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    custom = new Customer
                    {
                        CustomerID = dr.GetInt32("CustomerID"),
                        Lastname = dr.GetString("Lastname"),
                        Firstname = dr.GetString("Firstname"),
                        Phone = dr.GetString("Phone"),
                        Address = dr.GetString("Address"),
                        Postcode = dr.GetString("Postcode"),
                        City = dr.GetString("City")
                    };
                }
            }

            return custom;
        }

        /// <summary>
        /// method adds a new customer to the database.
        /// </summary>
        /// <param name="customer"></param>
        public void DBAddCustomer(Customer customer)
        {
            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("INSERT INTO Customer(Lastname, Firstname, Phone, Address, Postcode, City) " +
                    "VALUES (@Lastname, @Firstname, @Phone, @Address, @Postcode, @City)", conn);

                cmd.Parameters.AddWithValue("@Lastname", customer.Lastname);
                cmd.Parameters.AddWithValue("@Firstname", customer.Firstname);
                cmd.Parameters.AddWithValue("@Phone", customer.Phone);
                cmd.Parameters.AddWithValue("@Address", customer.Address);
                cmd.Parameters.AddWithValue("@Postcode", customer.Postcode);
                cmd.Parameters.AddWithValue("@City", customer.City);

                cmd.ExecuteNonQuery();
                MessageBox.Show($"Asiakas {customer.Firstname} {customer.Lastname} lisätty järjestelmään!");

            }
        }

        /// <summary>
        ///  Method removes the customer from the database.
        /// </summary>
        /// <param name="customer"></param>
        public void DBRemoveCustomer(Customer customer)
        {
            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("DELETE FROM Customer WHERE CustomerID=@CustomerID", conn);

                cmd.Parameters.AddWithValue("@CustomerID", customer.CustomerID);

                cmd.ExecuteNonQuery();

            }
        }

        /// <summary>
        ///  Method updates the customer's information
        /// </summary>
        /// <param name="customer"></param>
        public void DBUpdateCustomer(Customer customer)
        {
            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("UPDATE Customer SET Lastname=@lastname, Firstname=@firstname, Phone=@phone, Address=@address, Postcode=@postcode, City=@city WHERE CustomerID=@CustomerID", conn);

                cmd.Parameters.AddWithValue("@lastname", customer.Lastname);
                cmd.Parameters.AddWithValue("@firstname", customer.Firstname);
                cmd.Parameters.AddWithValue("@phone", customer.Phone);
                cmd.Parameters.AddWithValue("@address", customer.Address);
                cmd.Parameters.AddWithValue("@postcode", customer.Postcode);
                cmd.Parameters.AddWithValue("@city", customer.City);
                cmd.Parameters.AddWithValue("@CustomerID", customer.CustomerID);

                cmd.ExecuteNonQuery();

            }
        }

        public ObservableCollection<Bill> DBSearchCustomerBills(int customerID)
        {

            var bills = new ObservableCollection<Bill>();

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                //Komento SQL:lle
                var sql = "SELECT BillID, Date, DueDate, Description, RoomID FROM bill WHERE CustomerID = " + customerID;
                MySqlCommand cmd = new MySqlCommand(sql, conn);

                var dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    var newBill = new Bill
                    {
                        BillID = dr.GetInt32("BillID"),
                        Date = dr.GetDateTime("Date"),
                        DueDate = dr.GetDateTime("DueDate"),
                        Description = dr.GetString("Description"),
                        RoomID = dr.GetInt32("RoomID")
                    };


                    newBill = DBSearchCustomerInfoOnABill(newBill);
                    newBill = DBSearchBillsRoomInfo(newBill);
                    newBill.BillLines = DBSearchAllBillLines(newBill.BillID);
                    newBill = SearchRoomsReservationStartAndEnd(newBill);

                    bills.Add(newBill);
                }
            }


            return bills;
        }
        public Customer DBSearchCustomerWithBillID(int billID)
        {

            var customer = new Customer();
            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();
                var sql = "SELECT CustomerID, Lastname, Firstname, Phone, Address, Postcode, City FROM customer WHERE CustomerID = " +
                    $"( SELECT CustomerID FROM bill WHERE BillID = {billID});";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@BillID", billID);

                var dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    customer = new Customer
                    {
                        CustomerID = dr.GetInt32("CustomerID"),
                        Lastname = dr.GetString("Lastname"),
                        Firstname = dr.GetString("Firstname"),
                        Phone = dr.GetString("Phone"),
                        Address = dr.GetString("Address"),
                        Postcode = dr.GetString("Postcode"),
                        City = dr.GetString("City")

                    };
                }
            }
            return customer;
        }


        public Room DBSearchRoomWithRoomID(int roomID)
        {
            var room = new Room();
            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                //Komento SQL:lle
                var sql = "SELECT RoomID, Roomname, PriceForADay, Address, Postcode, City FROM room WHERE RoomID = " + roomID;
                MySqlCommand cmd = new MySqlCommand(sql, conn);

                var dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    room = new Room
                    {
                        RoomID = roomID,
                        Roomname = dr.GetString("Roomname"),
                        PriceForADay = dr.GetFloat("PriceForADay"),
                        Address = dr.GetString("Address"),
                        Postcode = dr.GetString("Postcode"),
                        City = dr.GetString("City")

                    };

                }
            }
            return room;

        }
        public ObservableCollection<BillLine> DBSearchBillLines(int billID)
        {
            var billLines = new ObservableCollection<BillLine>();

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                //Komento SQL:lle
                var sql = "SELECT * FROM billline WHERE BillID = " + billID;
                MySqlCommand cmd = new MySqlCommand(sql, conn);

                var dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    var line = new BillLine
                    {
                        LineID = dr.GetInt32("LineID"),
                        ServiceID = dr.GetInt32("ServiceID"),
                        RoomID = dr.GetInt32("RoomID"),
                        BillID = dr.GetInt32("BillID"),
                        Unit = dr.GetString("Unit"),
                        UnitPrice = dr.GetFloat("UnitPrice"),
                        Name = dr.GetString("Name"),
                        Amount = dr.GetInt32("Amount")

                    };
                    billLines.Add(line);
                }
            }


            return billLines;

        }

        public ObservableCollection<Bill> DBSearchAllBills()
        {

            var bills = new ObservableCollection<Bill>();

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                //Komento SQL:lle
                var sql = "SELECT BillID, Date, DueDate, Description, RoomID FROM bill";
                MySqlCommand cmd = new MySqlCommand(sql, conn);

                var dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    var newBill = new Bill
                    {
                        BillID = dr.GetInt32("BillID"),
                        Date = dr.GetDateTime("Date"),
                        DueDate = dr.GetDateTime("DueDate"),
                        Description = dr.GetString("Description"),
                        RoomID = dr.GetInt32("RoomID"),
                    };

                    newBill = DBSearchCustomerInfoOnABill(newBill);
                    newBill = DBSearchBillsRoomInfo(newBill);
                    newBill.BillLines = DBSearchAllBillLines(newBill.BillID);
                    newBill = SearchRoomsReservationStartAndEnd(newBill);


                    bills.Add(newBill);
                }
            }


            return bills;
        }
        private Bill DBSearchCustomerInfoOnABill(Bill bill)
        {

            var customer = new Customer();
            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();
                var sql = "SELECT CustomerID, Lastname, Firstname, Phone, Address, Postcode, City FROM customer WHERE CustomerID = " +
                    $"( SELECT CustomerID FROM bill WHERE BillID = {bill.BillID});";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@BillID", bill.BillID);

                var dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    customer = new Customer
                    {
                        CustomerID = dr.GetInt32("CustomerID"),
                        Lastname = dr.GetString("Lastname"),
                        Firstname = dr.GetString("Firstname"),
                        Phone = dr.GetString("Phone"),
                        Address = dr.GetString("Address"),
                        Postcode = dr.GetString("Postcode"),
                        City = dr.GetString("City")

                    };

                }

            }
            bill.CustomerInfo = customer;
            return bill;
        }
        public Bill DBSearchBillsRoomInfo(Bill bill)
        {
            var room = new Room();

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                //Komento SQL:lle
                var sql = "SELECT RoomID, Roomname, PriceForADay, Address, Postcode, City FROM room WHERE RoomID = " + bill.RoomID;
                MySqlCommand cmd = new MySqlCommand(sql, conn);

                var dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    room = new Room
                    {
                        RoomID = bill.RoomID,                       
                        Roomname = dr.GetString("Roomname"),
                        PriceForADay = dr.GetFloat("PriceForADay"),
                        Address = dr.GetString("Address"),
                        Postcode = dr.GetString("Postcode"),
                        City = dr.GetString("City")

                    };
                }
            }

            bill.Room = room;
            return bill;

        }
        public Bill SearchRoomsReservationStartAndEnd(Bill bill)
        {
            var room = new Room();

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

              
                var sql = "SELECT ReservationStarts, ReservationEnds FROM bill WHERE BillID = " + bill.BillID;

                MySqlCommand cmd = new MySqlCommand(sql, conn);

                var dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    room = new Room
                    {
                        ReservationEnds = dr.GetDateTime("ReservationEnds"),
                        ReservationStarts = dr.GetDateTime("ReservationStarts")
                    };
                }

            }
            bill.Room.ReservationStarts = room.ReservationStarts;
            bill.Room.ReservationEnds = room.ReservationEnds;
            return bill;

        }
        private ObservableCollection<BillLine> DBSearchAllBillLines(int billID)
        {
            var billLines = new ObservableCollection<BillLine>();

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                //Komento SQL:lle
                var sql = "SELECT * FROM billline WHERE BillID = " + billID;
                MySqlCommand cmd = new MySqlCommand(sql, conn);

                var dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    var line = new BillLine
                    {
                        LineID = dr.GetInt32("LineID"),
                        ServiceID = dr.GetInt32("ServiceID"),
                        RoomID = dr.GetInt32("RoomID"),
                        BillID = dr.GetInt32("BillID"),
                        Unit = dr.GetString("Unit"),
                        UnitPrice = dr.GetFloat("UnitPrice"),
                        Name = dr.GetString("Name"),
                        Amount = dr.GetInt32("Amount")

                    };
                    billLines.Add(line);
                }
            }

            return billLines;

        }

        public ObservableCollection<Room> GetRoomReservationStartAndEnd(int roomID)
        {
            var rooms = new ObservableCollection<Room>();

            var sql = "SELECT ReservationStarts, ReservationEnds FROM bill WHERE RoomID =" + roomID;

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                //Komento SQL:lle

                MySqlCommand cmd = new MySqlCommand(sql, conn);

                var dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    rooms.Add(new Room
                    {
                        ReservationStarts = dr.GetDateTime("ReservationStarts"),
                        ReservationEnds = dr.GetDateTime("ReservationEnds")
                    });

                }
            }
            return rooms;

        }



        /// <summary>
        /// Add the bill received by parameter to the database.
        /// </summary>
        /// <param name = "bill" ></ param >

        public void DBUpdateBill(Bill bill)
        {
            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();
                var sql = "UPDATE bill SET DATE=@Date, DueDate=@DueDate, ReservationStarts=@ReservationStarts, ReservationEnds=@ReservationEnds, CustomerID=@CustomerID, RoomID=@RoomID, Description=@Description WHERE BillID = " + "'" + bill.BillID + "'";

                MySqlCommand cmd = new MySqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@Date", bill.Date);
                cmd.Parameters.AddWithValue("@DueDate", bill.DueDate);
                cmd.Parameters.AddWithValue("@ReservationStarts", bill.Room.ReservationStarts);
                cmd.Parameters.AddWithValue("@ReservationEnds", bill.Room.ReservationEnds);
                cmd.Parameters.AddWithValue("@CustomerID", bill.CustomerInfo.CustomerID);
                cmd.Parameters.AddWithValue("@RoomID", bill.Room.RoomID);
                cmd.Parameters.AddWithValue("@Description", bill.Description);
                cmd.ExecuteNonQuery();
      
            }
            DBUpdateBillLines(bill);

        }

        public void DBUpdateBillLines(Bill bill)
        {
            DeleteBillLines(bill.BillID);


            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();
                foreach (var line in bill.BillLines)
                {
                    MySqlCommand cmd = new MySqlCommand("INSERT INTO billline(Name, Unit, UnitPrice, Amount, ServiceID, RoomID, BillID)VALUES " +
                        "(@Name, @Unit, @UnitPrice, @Amount, @ServiceID, @RoomID, @BillID)", conn);
                    cmd.Parameters.AddWithValue("@Name", line.Name);
                    cmd.Parameters.AddWithValue("@Unit", line.Unit);
                    cmd.Parameters.AddWithValue("@UnitPrice", line.UnitPrice);
                    cmd.Parameters.AddWithValue("@Amount", line.Amount);
                    cmd.Parameters.AddWithValue("@ServiceID", line.ServiceID);
                    cmd.Parameters.AddWithValue("@RoomID", line.RoomID);
                    cmd.Parameters.AddWithValue("@BillID", bill.BillID);

                    cmd.ExecuteNonQuery();
                }

            }
        }

        public void DBAddBill(Bill bill)
        {

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("INSERT INTO bill(Date, DueDate, ReservationStarts, ReservationEnds, CustomerID, RoomID, Description)VALUES (@Date, @DueDate, @ReservationStarts, @ReservationEnds, @CustomerID, @RoomID, @Description)", conn);

                cmd.Parameters.AddWithValue("@Date", bill.Date);
                cmd.Parameters.AddWithValue("@DueDate", bill.DueDate);
                cmd.Parameters.AddWithValue("@ReservationStarts", bill.Room.ReservationStarts);
                cmd.Parameters.AddWithValue("@ReservationEnds", bill.Room.ReservationEnds);
                cmd.Parameters.AddWithValue("@CustomerID", bill.CustomerInfo.CustomerID);
                cmd.Parameters.AddWithValue("@RoomID", bill.Room.RoomID);
                cmd.Parameters.AddWithValue("@Description", bill.Description);
                cmd.ExecuteNonQuery();
               
            }
            int id = DBGetTheLatestCreatedBillID();

            if (bill.BillLines.Count > 0)
            {

                DBAddBillLine(bill.BillLines, id);

            }
        }

        private void DBAddBillLine(ObservableCollection<BillLine> lines, int billID)
        {
            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();
                foreach (var line in lines)
                {
                    MySqlCommand cmd = new MySqlCommand("INSERT INTO billline(Name, Unit, UnitPrice, Amount, ServiceID, RoomID, BillID)VALUES " +
                        "(@Name, @Unit, @UnitPrice, @Amount, @ServiceID, @RoomID, @BillID)", conn);
                    cmd.Parameters.AddWithValue("@Name", line.Name);
                    cmd.Parameters.AddWithValue("@Unit", line.Unit);
                    cmd.Parameters.AddWithValue("@UnitPrice", line.UnitPrice);
                    cmd.Parameters.AddWithValue("@Amount", line.Amount);
                    cmd.Parameters.AddWithValue("@ServiceID", line.ServiceID);
                    cmd.Parameters.AddWithValue("@RoomID", line.RoomID);
                    cmd.Parameters.AddWithValue("@BillID", billID);

                    cmd.ExecuteNonQuery();
                }
            }
        }

        private int DBGetTheLatestCreatedBillID()
        {
            var id = 0;
            var services = new ObservableCollection<Service>();

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                var sql = "SELECT MAX(BillID) FROM Bill";

                MySqlCommand cmd = new MySqlCommand(sql, conn);

                var dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    id = dr.GetInt32("MAX(BillID)");

                }
            }
            return id;
        }


        public void DeleteBill(int billID)
        {
            DeleteBillLines(billID);


            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("DELETE FROM Bill WHERE BillID=@BillID", conn);

                cmd.Parameters.AddWithValue("@BillID", billID);

                cmd.ExecuteNonQuery();

            }
        }
        private void DeleteBillLines(int billID)
        {
            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("DELETE FROM Billline WHERE BillID=@BillID", conn);

                cmd.Parameters.AddWithValue("@BillID", billID);

                cmd.ExecuteNonQuery();

            }

        }

        public ObservableCollection<BillLine> DBSearchServiceInBills(int serviceID)
        {

            var billLines = new ObservableCollection<BillLine>();

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                //Komento SQL:lle
                var sql = "SELECT * FROM billline WHERE ServiceID = " + serviceID;
                MySqlCommand cmd = new MySqlCommand(sql, conn);

                var dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    var line = new BillLine
                    {
                        LineID = dr.GetInt32("LineID"),
                        ServiceID = dr.GetInt32("ServiceID"),
                        RoomID = dr.GetInt32("RoomID"),
                        BillID = dr.GetInt32("BillID"),
                        Unit = dr.GetString("Unit"),
                        UnitPrice = dr.GetFloat("UnitPrice"),
                        Name = dr.GetString("Name"),
                        Amount = dr.GetInt32("Amount")

                    };
                    billLines.Add(line);
                }
            }

            return billLines;
        }

        public  Bill DBSearchBillService(int billineID)
        {
           Bill bill = null;

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                //Komento SQL:lle
                var sql = "SELECT * FROM bill WHERE BillID = " + billineID;
                MySqlCommand cmd = new MySqlCommand(sql, conn);

                var dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    bill = new Bill
                    {
                        BillID = dr.GetInt32("BillID"),
                        Date = dr.GetDateTime("Date"),
                        DueDate = dr.GetDateTime("DueDate"),
                        Description = dr.GetString("Description"),
                        RoomID = dr.GetInt32("RoomID"),

                    };
                }
            }

            return bill;
        }


        public ObservableCollection<Service> DBGEtRoomsServices(int rooomid)
        {
            var services = new ObservableCollection<Service>();

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                var sql = "SELECT ServiceID, ServiceName, Unit, UnitPrice, RoomID FROM service WHERE RoomID =" + rooomid;

                MySqlCommand cmd = new MySqlCommand(sql, conn);

                var dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    services.Add(new Service
                    {
                        Service_ID = dr.GetInt32("ServiceID"),
                        ServiceName = dr.GetString("ServiceName"),
                        Unit = dr.GetString("Unit"),
                        Price = dr.GetFloat("UnitPrice"),


                    }); ;

                }

            }

            return services;
        }

        public ObservableCollection<Service> DBGetServices()
        {
            var services = new ObservableCollection<Service>();

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                var sql = "SELECT ServiceID, ServiceName, Unit, UnitPrice, RoomID FROM service";

                MySqlCommand cmd = new MySqlCommand(sql, conn);

                var dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    services.Add(new Service
                    {
                        Service_ID = dr.GetInt32("ServiceID"),
                        ServiceName = dr.GetString("ServiceName"),
                        Unit = dr.GetString("Unit"),
                        Price = dr.GetFloat("UnitPrice"),
                        RoomID = dr.GetInt32("RoomID"),


                    }); ;

                }
            }

            return services;
        }

        public ObservableCollection<Service> DBGetServicesWithRoomInfo()
        {
            var services = new ObservableCollection<Service>();

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                var sql = "SELECT ServiceID, ServiceName, Unit, UnitPrice, RoomID FROM service";

                MySqlCommand cmd = new MySqlCommand(sql, conn);

                var dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    services.Add(new Service
                    {
                        Service_ID = dr.GetInt32("ServiceID"),
                        ServiceName = dr.GetString("ServiceName"),
                        Unit = dr.GetString("Unit"),
                        Price = dr.GetFloat("UnitPrice"),
                        RoomID = dr.GetInt32("RoomID")


                    }); ;

                }
                foreach (var service in services)
                {
                    service.Room = DBSearchRoomWithID(service.RoomID);

                }
            }

            return services;
        }
        


        /// <summary>
        /// Add service to database.
        /// </summary>
        /// <param name="service"></param>
        public void DBAddService(Service service, int roomID)
        {
            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("INSERT INTO Service (ServiceName, Unit, UnitPrice, RoomID) VALUES (@Servicename, @Unit, @Price, @RoomID)", conn);

                cmd.Parameters.AddWithValue("@Servicename", service.ServiceName);
                cmd.Parameters.AddWithValue("@Unit", service.Unit);
                cmd.Parameters.AddWithValue("@Price", service.Price);
                cmd.Parameters.AddWithValue("@RoomID", roomID);

                cmd.ExecuteNonQuery();

            }

        }

        ///// <summary>
        ///// Searches for an individual room based on its name and returns the room
        ///// </summary>
        ///// <param name="roomname"></param>

        public ObservableCollection<Room> DBSearchAllRooms()
        {
            var rooms = new ObservableCollection<Room>();

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {

                conn.Open();

                MySqlCommand cmd = new MySqlCommand("SELECT * FROM room", conn);

                var dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    

                    rooms.Add(new Room
                    {
                        RoomID = dr.GetInt32("RoomID"),
                        Roomname = dr.GetString("Roomname"),
                        RoomSize = dr.GetString("RoomSize"),
                        Address = dr.GetString("address"),
                        Postcode = dr.GetString("postcode"),
                        City = dr.GetString("city"),
                        PriceForADay = dr.GetFloat("PriceForADay")
                       
                    });
                }

                return rooms;
            }

        }

        public Room DBSearchRoom(string roomname)
        {
            Room newRoom = null;

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {

                conn.Open();

                MySqlCommand cma = new MySqlCommand("SELECT * FROM room WHERE Roomname=@Roomname", conn);
                cma.Parameters.AddWithValue("@Roomname", roomname);

                var dr = cma.ExecuteReader();

                if (dr.Read())
                {
                    newRoom = new Room
                    {
                        RoomID = dr.GetInt32("RoomID"),
                        Roomname = dr.GetString("Roomname"),
                        Address = dr.GetString("address"),
                        Postcode = dr.GetString("postcode"),
                        City = dr.GetString("city"),
                        RoomSize = dr.GetString("Roomsize"),
                        PriceForADay = dr.GetFloat("PriceForADay")
                    };
                }

                return newRoom;
            }
        }


        public ObservableCollection<Room> DBGetAllRooms()
        {
            ObservableCollection<Room> rooms = new ObservableCollection<Room>();

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {

                conn.Open();

                MySqlCommand cma = new MySqlCommand("SELECT * FROM room", conn);

                var dr = cma.ExecuteReader();

                while (dr.Read())
                {
                    rooms.Add(new Room
                    {
                        RoomID = dr.GetInt32("RoomID"),
                        Roomname = dr.GetString("Roomname"),
                        RoomSize = dr.GetString("RoomSize"),
                        PriceForADay = dr.GetFloat("PriceForADay"),
                        Address = dr.GetString("address"),
                        Postcode = dr.GetString("postcode"),
                        City = dr.GetString("city")
                    });
                }
                return rooms;
            }
        }

        public Room DBSearchRoomWithID(int roomid)
        {
            Room newRoom = null;

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {

                conn.Open();

                MySqlCommand cma = new MySqlCommand("SELECT * FROM room WHERE RoomID=@RoomID", conn);
                cma.Parameters.AddWithValue("@RoomID", roomid);

                var dr = cma.ExecuteReader();

                if (dr.Read())
                {
                    newRoom = new Room
                    {
                        RoomID = dr.GetInt32("RoomID"),
                        Roomname = dr.GetString("Roomname"),
                        Address = dr.GetString("address"),
                        Postcode = dr.GetString("postcode"),
                        City = dr.GetString("city"),
                        PriceForADay = dr.GetFloat("PriceForADay")
                    };
                }

                return newRoom;
            }

        }


        public void DBAddRoom(Room room)
        {
            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("INSERT INTO Room(Roomname, Address, Postcode, City, RoomSize, PriceForADay) " +
                    "VALUES (@Roomname, @Address, @Postcode, @City, @RoomSize, @PriceForADay)", conn);

                cmd.Parameters.AddWithValue("@Roomname", room.Roomname);
                cmd.Parameters.AddWithValue("@Address", room.Address);
                cmd.Parameters.AddWithValue("@Postcode", room.Postcode);
                cmd.Parameters.AddWithValue("@City", room.City);
                cmd.Parameters.AddWithValue("@RoomSize", room.RoomSize);
                cmd.Parameters.AddWithValue("@PriceForADay", room.PriceForADay);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Toimitila lisätty onnistuneesti!");

            }
        }


        public void DBUpdateRoom(Room room)
        {
            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("UPDATE Room SET Roomname=@Roomname, RoomSize=@roomsize, Address=@Address, Postcode=@PostalCode, PriceForADay=@Price, City=@City WHERE RoomID=@RoomID", conn);

                cmd.Parameters.AddWithValue("@Roomname", room.Roomname);
                cmd.Parameters.AddWithValue("@Address", room.Address);
                cmd.Parameters.AddWithValue("@roomsize", room.RoomSize);
                cmd.Parameters.AddWithValue("@PostalCode", room.Postcode);
                cmd.Parameters.AddWithValue("@Price", room.PriceForADay);
                cmd.Parameters.AddWithValue("@City", room.City);
                cmd.Parameters.AddWithValue("@RoomID", room.RoomID);

                cmd.ExecuteNonQuery();

            }
        }

        public string CheckIfRoomIsOnABill(int roomid)
        {
            var bills = new List<Bill>();
            var ids = string.Empty;

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                var sql = "SELECT BillID FROM bill WHERE RoomID = " + roomid;

                MySqlCommand cmd = new MySqlCommand(sql, conn);

                var dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    bills.Add(new Bill
                    {
                        BillID = dr.GetInt32("BillID"),
                       
                    }); ; ;

                }

            }

            int i = 0;

            foreach (Bill bill in bills)
            {
                i++;
                
                ids +=  bill.BillID;
                if (i != bills.Count) 
                {
                    ids += ", ";
                }
                else
                {
                    ids += ".";
                }

            }
                        
            return ids;

        }

        public void DBDeleteOffice(int roomID)
        {
            DBDeleteRoomsServices(roomID);


            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                var sql = "DELETE FROM room WHERE RoomID = " + roomID;

                MySqlCommand cmd = new MySqlCommand(sql, conn);
          
                cmd.ExecuteNonQuery();

            }

        }

        private void DBDeleteRoomsServices(int roomID)
        {

      
            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                var sql = "DELETE FROM service WHERE RoomID = " + roomID;

                MySqlCommand cmd = new MySqlCommand(sql, conn);

                cmd.ExecuteNonQuery();

            }

        }


        //adds one service to the database
        public void AddService(Service service)
        {
            //connecting to the database motor and database
            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                //adding information to the database
                //making the Insert sentences with parameters, in order to avoid SQL-injections

                MySqlCommand cmd = new MySqlCommand("INSERT INTO service(serviceid, servicename, unit, unitprice, roomid) VALUES(@serviceid, @servicename, @unit, @price, @roomid)", conn);
                //adds values to the parameters
                cmd.Parameters.AddWithValue("@serviceid", service.Service_ID);
                cmd.Parameters.AddWithValue("@servicename", service.ServiceName);
                cmd.Parameters.AddWithValue("@unit", service.Unit);
                cmd.Parameters.AddWithValue("@unitprice", service.Price);
                cmd.Parameters.AddWithValue("@roomid", service.RoomID);

                //executes this command
                cmd.ExecuteNonQuery();

            }

        }

        //method for updating service
        public void UpdateService(Service service)
        {

            //connecting with the database motor and database
            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                //adding information to  the database
                //making the Insert sentences with parameters, because we are trying to avoid SQL-injections
                MySqlCommand cmd = new MySqlCommand("UPDATE service SET ServiceName=@servicename, Unit=@unit, UnitPrice=@unitprice WHERE ServiceID=@serviceid", conn);
                //adding values to parameters
                cmd.Parameters.AddWithValue("@serviceid", service.Service_ID);
                cmd.Parameters.AddWithValue("@servicename", service.ServiceName);
                cmd.Parameters.AddWithValue("@unit", service.Unit);
                cmd.Parameters.AddWithValue("@unitprice", service.Price);

                //executes this command
                cmd.ExecuteNonQuery();

            }

        }


        // Method for finding all bill IDs that a service is assigned to
        public string SearchAllBillIDsThatServiceIsAssignetTo(int serviceID)
        {
            List<string> lista = new List<string>();
            int IDint = 0;
            string id = "";

            // SQL query to select all bill IDs for the given service ID
            var sql = "SELECT BillID FROM billline WHERE ServiceID =" + serviceID;

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                // Execute the SQL query
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                var dr = cmd.ExecuteReader();

                // Loop through the results and add each bill ID to a list
                while (dr.Read())
                {
                    IDint = dr.GetInt32("BillID");
                    id = IDint.ToString();
                    lista.Add(id);
                }

                // Combine the bill IDs into a comma-separated string
                var bills = "";
                var counter = 0;
                foreach (var item in lista)
                {
                    counter++;
                    bills += item.ToString();
                    if (lista.Count > counter)
                    {
                        bills += ", ";
                    }
                }

                // Return the comma-separated string of bill IDs
                return bills;
            }
        }


        public void RemoveService(Service service)
        {
            //connecting with the database motor and database
            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                //making the Delete sentences with parameters, because we are trying to avoid SQL-injections 
                MySqlCommand cmd = new MySqlCommand("DELETE FROM service WHERE serviceid=@serviceid", conn);
                //adds values to the parameters
                cmd.Parameters.AddWithValue("@serviceid", service.Service_ID);

                //executes this command
                cmd.ExecuteNonQuery();
            }
        }
    }
}

