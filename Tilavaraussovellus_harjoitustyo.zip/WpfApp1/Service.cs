﻿using System;
using System.Collections.ObjectModel;

namespace WpfApp1
{
    
    public class Service
    {
        public int Service_ID { get; set; }
        public string ServiceName { get; set; }
        public string Unit { get; set; }
        public float Price { get; set; }
        public int RoomID { get; set; }

        public Bill Bill { get; set; }

        public Room Room { get; set; }
        public string ServiceInfo { get { return $"{Unit}: {ServiceName}, PalveluID:{Service_ID}\nTila: {Room.Roomname}, TilaID:{Room.RoomID}\nOsoite: {Room.Address}, {Room.Postcode}, {Room.City}"; } }
        public string Name_Roomname_Address { get { return $"{Unit}: {ServiceName} \nTila: {Room.Roomname} \nTilaID: {RoomID}\nOsoite: {Room.Address}, {Room.Postcode}, {Room.City}"; } }
        public ObservableCollection<Room> Rooms { get; set; }

        public int BillIDs { get; set; }
        public string BillInfos { get; set; }


        public Service()
        {
            Service_ID = -1;
            ServiceName = string.Empty;
            Unit = string.Empty;
            Price = 0;
            RoomID = 0;
            Rooms = new ObservableCollection<Room>();
            Room = new Room();

            Repository repo = new Repository();

            Room = repo.DBSearchRoomWithRoomID(RoomID);
        }
    }
}
   
