﻿using System;

namespace WpfApp1
{
    public class Room
    {

        public Room()
        {
            RoomID = -1;
            Roomname = string.Empty;
            RoomSize = string.Empty;
            PriceForADay = 0;
            ReservationStarts = DateTime.Now.Date;
            ReservationEnds = DateTime.Now.Date;
            Address = string.Empty;
            Postcode = string.Empty;
            City = string.Empty;
        }


        public int RoomID { get; set; }
        public string Roomname { get; set; }
        public string RoomSize { get; set; }
        public float PriceForADay { get; set; }
        
        public DateTime ReservationStarts { get; set; }
        public DateTime ReservationEnds { get; set; }
        public string Address { get; set; }
        public string Postcode { get; set; }
        public string City { get; set; }
        public string RoomInfo
        {
            get
            {
                return $"Tilan nimi: {Roomname}, TilaID: {RoomID}\n" +
                    $"Hinta päivältä: {PriceForADay}\n" +
                    $"Osoite: {Address}, {Postcode}, {City}\n" +
                    "---------------   ";
            }
        }


    }


}
   
