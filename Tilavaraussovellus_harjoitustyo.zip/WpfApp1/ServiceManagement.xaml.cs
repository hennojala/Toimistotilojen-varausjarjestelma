﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for Lisäpalveluview.xaml
    /// </summary>
    public partial class ServiceManagement : Window
    {
        public Repository repo;

        public ObservableCollection<Service> Services;
        public Service Service { get; set; }

        public ServiceManagement()
        {
            InitializeComponent();

            repo = new Repository();

            RefreshServiceList();


        }

        //event handler AddPalvelu where there is a new ilmentymä of the user interface
        //and it is shown to the user
        private void buttonAddService_click(object sender, RoutedEventArgs e)
        {
            ServiceAdd addNew = new ServiceAdd();
            var returnValue = addNew.ShowDialog();

            if (returnValue == true)
            {
                //Refresh service list
                RefreshServiceList();
            }
        }

        //event handler for opening a new user interface
        //where the chosen service can be updated
        private void UpdateSelected(object sender, RoutedEventArgs e)
        {
            var service = (Service)serviceListView.SelectedValue;
            if (service != null)
            {
                ServiceEdit updatePalvelu = new ServiceEdit(service);
                var returnValue = updatePalvelu.ShowDialog();

                if (returnValue == true)
                {
                    //Refresh service list
                    RefreshServiceList();
                }
            }
            else
            {
                MessageBox.Show("Valitse ensin lisäpalvelu tai -tuote", "Ei valintaa");
            }
        }

        //we get the service that we want to remove from the listview here
        private void RemoveSelectedPalvelu(object sender, RoutedEventArgs e)
        {
            var service = (Service)serviceListView.SelectedValue;

            if (service != null)
            {
                ObservableCollection<BillLine> bills = repo.DBSearchServiceInBills(service.Service_ID);

                if (bills.Count == 0)
                {
                    var result = MessageBox.Show("Haluatko varmasti poistaa valitun lisäpalvelun?", "Varoitus", MessageBoxButton.YesNo, MessageBoxImage.Question);
                    if (result == MessageBoxResult.Yes)
                    {
                        repo.RemoveService(service);
                        //Refresh service list
                        RefreshServiceList();
                    }
                }
                else
                {
                    MessageBox.Show("Et voi poistaa lisäpalvelua, josta on laskuja järjestelmässä.", "Lisäpalvelua ei voi poistaa");
                }
            }
            else
            {
                MessageBox.Show("Valitse ensin lisäpalvelu tai -tuote", "Ei valintaa");
            }
        }

        //Refresh listview
        private void RefreshServiceList()
        {
            var services = repo.DBGetServices();
            ObservableCollection<BillLine> servicebills;
            Customer custom;
            Room room;
            foreach (Service service in services)
            {


                service.Room = repo.DBSearchRoomWithRoomID(service.RoomID);
                servicebills = repo.DBSearchServiceInBills(service.Service_ID);

                if (servicebills.Count == 0)
                {
                    service.BillInfos = "Lisäpalvelu ei ole yhdelläkään laskulla.";
                }

                else
                {
                    foreach (BillLine line in servicebills)
                    {
                        Bill bill = repo.DBSearchBillService(line.BillID);
                        Bill daysBill = repo.SearchRoomsReservationStartAndEnd(bill);
                        custom = repo.DBSearchCustomerWithBillID(line.BillID);

                        service.Room = repo.DBSearchRoomWithRoomID(service.RoomID);

                        service.BillInfos += $"\nLaskuID: {line.BillID}\nVarausaika: {daysBill.Room.ReservationStarts.ToShortDateString()}-{daysBill.Room.ReservationEnds.ToShortDateString()}\nRiviID: {line.LineID}\nAsiakas: {custom.Name}\n";
                        
                    }
                }
            }


            // Update the list view
            serviceListView.ItemsSource = services;
            serviceListView.SelectedItem = null;
        }

        /// <summary>
        /// This method is a handler for the TextChanged event of a search box.
        /// It retrieves the search text from the box and uses it to filter a list of services.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void searchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            // Get the search text from the search box
            string searchText = searchBox.Text.ToLower();

            // If the search text is empty, show all services
            if (searchText.Length == 0)
            {
                // Get all services from the database
                var services = repo.DBGetServices();

                // For each service, get the room information from the database and assign it to the service
                foreach (Service service in services)
                {
                    service.Room = repo.DBSearchRoomWithRoomID(service.RoomID);
                }

                // Set the service list view's item source to the list of services
                serviceListView.ItemsSource = services;
            }
            else
            {
                // If there is search text, filter the services based on the search text

                // Get all services from the database and filter them based on the search text
                var services = repo.DBGetServices()
                    .Where(c => c.ServiceName.ToLower().Contains(searchText) ||
                                c.Unit.ToLower().Contains(searchText) ||
                                c.Service_ID.ToString().ToLower().Contains(searchText) ||
                                c.RoomID.ToString().ToLower().Contains(searchText));

                // For each service, get the room information from the database and assign it to the service
                foreach (Service service in services)
                {
                    service.Room = repo.DBSearchRoomWithRoomID(service.RoomID);
                }

                // Set the service list view's item source to the filtered list of services
                serviceListView.ItemsSource = services;
            }
        }


        // Close this window
        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
