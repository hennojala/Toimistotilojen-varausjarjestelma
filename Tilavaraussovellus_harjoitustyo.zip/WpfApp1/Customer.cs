﻿namespace WpfApp1
{
    public class Customer
    {
        public int CustomerID { get; set; }
        public string Lastname { get; set; }
        public string Firstname { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
        public string Postcode { get; set; }
        public string City { get; set; }

        public string Name
        {
            get { return Lastname + " " + Firstname; }
        }

        public Customer()
        {
            CustomerID = -1;
            Lastname = string.Empty;
            Firstname = string.Empty;
            Phone = string.Empty;
            Address = string.Empty;
            Postcode = string.Empty;
            City = string.Empty;
        }
    }


}
   
