﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation.Text;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for UpdatePalvelu.xaml
    /// </summary>
    public partial class ServiceEdit : Window
    {
        public Service Service { get; set; }
        public Repository Repository { get; set; }
        public ServiceEdit(Service service)
        {
            InitializeComponent();

            Service = service;
            Repository = new Repository();
            var tool = new Repository();

            bool found = tool.DBSearchServiceInBills(service.Service_ID).Any(s => s.ServiceID == service.Service_ID);

            if (found == true)
            {
                ObservableCollection<BillLine> lines = tool.DBSearchServiceInBills(service.Service_ID);

                foreach (BillLine line in lines)
                {
                    lblBill_IDs.Content += " LaskuID:" +line.BillID.ToString()+ "\n";
                }
            }

            else
            {
                lblBill_IDs.Content = "Ei laskuja";
            }

            this.DataContext = Service;
        }



        private void btnClose(object sender, RoutedEventArgs e)
        {
            Close();
        }

        //event handler for the UpdateService Update-button

        private void UpdateClick(object sender, RoutedEventArgs e)
        {
            bool onfloat = float.TryParse(txtPrice.Text.Replace(".", ","), out float num);


            if (txtName.Text == string.Empty || txtUnit.Text == string.Empty)
            {
                MessageBox.Show("Kentät ei voi olla tyhjiä");

            }
            else
            {
                if (onfloat)
                {
                    Service = (Service)this.DataContext;

                    Service.Price = num;
                    Repository.UpdateService(Service);

                    MessageBox.Show($"Lisäpalvelu {Service.ServiceName} päivitetty järjestelmään!");

                    DialogResult = true;

                }
                else
                {
                    MessageBox.Show("Tuotteen hinta on syötetty väärin");
                }
            }
        }

        // Auxiliary variable for checking whether decimal separator has been used or not
        private bool isDecimalUsed = false;

        /// <summary>
        /// Event listener that prevents user from entering invalid characters and converts the input to a decimal number regardless of using comma or dot as a decimal separator.
        /// </summary>
        /// <param name = "sender" ></ param >
        /// < param name="e"></param>
        private void txtPrice_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {

            // Reset decimal usage flag if user inputs a new value
            if (txtPrice.CaretIndex == txtPrice.Text.Length && !string.IsNullOrEmpty(e.Text))
            {
                isDecimalUsed = false;
            }

            // Check that input is a combination of digits, comma or dot
            Regex regex = new Regex("[^0-9.,]+");
            if (regex.IsMatch(e.Text))
            {
                e.Handled = true;
            }
            else if (e.Text == ",")
            {
                // If user enters a comma, replace it with a dot
                e.Handled = true;
                if (!isDecimalUsed)
                {
                    isDecimalUsed = true;
                    txtPrice.Text += ".";
                    txtPrice.CaretIndex = txtPrice.Text.Length;
                }
            }
            else if (e.Text == ".")
            {
                // If user enters a dot, check that it hasn't been used already
                e.Handled = true;
                if (!isDecimalUsed)
                {
                    isDecimalUsed = true;
                    txtPrice.Text += ".";
                    txtPrice.CaretIndex = txtPrice.Text.Length;
                }
            }
            else
            {
                // Check that the input contains only one comma or dot
                string text = txtPrice.Text + e.Text;
                int dotCount = text.Count(c => c == '.');
                int commaCount = text.Count(c => c == ',');
                if (dotCount + commaCount > 1)
                {
                    e.Handled = true;
                }
            }
        }
    }
}
