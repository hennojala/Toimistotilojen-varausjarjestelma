﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for OfficeList.xaml
    /// </summary>
    /// 

    public partial class OfficeManagement : Window
    {
        public int Index { get; set; }

        public ObservableCollection<Room> Rooms { get; set; }

        public Repository tool;


        public OfficeManagement()
        {
            InitializeComponent();

            tool = new Repository();
            Rooms = new ObservableCollection<Room>();    

            RefreshRoomList();

        }

        private void RefreshRoomList()
        {
            var rooms = tool.DBSearchAllRooms();
            
            roomsListView.ItemsSource = rooms;
            roomsListView.SelectedItem = null;
        }


        private void Close_List_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Edit_Office_Click(object sender, RoutedEventArgs e)
        {
            var selectedRoom = roomsListView.SelectedItem as Room;
           
            if (selectedRoom == null)
            {
                MessageBox.Show("Valitse ensin muokattava huone.", "Virhe");
                return;
            }
            else
            {
                var editWindow = new OfficeEdit(selectedRoom);
                if (editWindow.ShowDialog() == true)
                {
                    RefreshRoomList();
                    
                }

            }
            
        }

        // searchbox
        private void searchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            // Get the search text from the search box
            string searchText = searchBox.Text.ToLower();

            // Filter the room list view based on the search text
            if (searchText.Length == 0)
            {
                roomsListView.ItemsSource = tool.DBSearchAllRooms();
            }
            else
            {
                roomsListView.ItemsSource = tool.DBSearchAllRooms().Where(c => c.RoomID.ToString().ToLower().Contains(searchText) ||
                                                                           c.Roomname.ToLower().Contains(searchText) ||
                                                                           c.RoomSize.ToLower().Contains(searchText) ||
                                                                           c.Address.ToLower().Contains(searchText) ||
                                                                           c.Postcode.ToLower().Contains(searchText) ||
                                                                           c.City.ToLower().Contains(searchText));
            }
        }

        private void Delete_Office_Click(object sender, RoutedEventArgs e)
        {
            var selectedRoom = roomsListView.SelectedItem as Room;

            if (selectedRoom == null)
            {
                MessageBox.Show("Valitse ensin poistettava huone.", "Virhe");

            }
            else
            {
                var result = MessageBox.Show("Haluatko varmasti poistaa toimitilan?", "Poiston vahvistus", MessageBoxButton.YesNo,
           MessageBoxImage.Question);
                if (result == MessageBoxResult.Yes)
                {
                    var ids = string.Empty;
                    ids = tool.CheckIfRoomIsOnABill(selectedRoom.RoomID);
                    if (ids == string.Empty)
                    {
                        //pitää tarkistaa toimiiko
                        tool.DBDeleteOffice(selectedRoom.RoomID);
                        MessageBox.Show("Huone poistettu", "Vahvistus");


                    }
                    else
                    {
                        MessageBox.Show("Huonetta ei voida poistaa, sillä se on laskuissa: " + ids);

                    }
                }
                RefreshRoomList();
            }
        }

        //open add new office window
        private void AddNewClick(object sender, RoutedEventArgs e)
        {
            // Create a new room object
            Room room = new Room();

            // Show the add room window and set its DataContext to the new customer object
            var addWindow = new OfficeAdd(room);
            if (addWindow.ShowDialog() == true)
            {
                // Refresh the room list
                RefreshRoomList();

            }
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
