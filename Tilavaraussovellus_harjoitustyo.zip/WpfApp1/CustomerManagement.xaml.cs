﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static WpfApp1.MainWindow;

namespace WpfApp1
{
    public partial class CustomerManagement : Window
    {
        public Repository dbTool;

        public CustomerManagement()
        {
            InitializeComponent();

            dbTool = new Repository();

            var customers = dbTool.DBSearchAllCustomers();
            this.DataContext = customers[0];

            RefreshCustomerList();

        }

        // open add new customer -window
        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            // Create a new customer object
            Customer customer = new Customer();

            // Show the customer edit window and set its DataContext to the new customer object
            var addWindow = new CustomerAdd(customer);
            if (addWindow.ShowDialog() == true)
            {             

                // Refresh the customer list
                RefreshCustomerList();
            }
        }

        // open update to the selected customer -window
        private void editButton_Click(object sender, RoutedEventArgs e)
        {
            // Get the selected customer from the list
            var selectedCustomer = (Customer)customerListView.SelectedItem;
            if (selectedCustomer == null)
            {
                MessageBox.Show("Valitse ensin muokattava asiakas.", "Virhe");
                return;
            }

            // Show the customer edit window and set its DataContext to the selected customer object
            var editWindow = new CustomerEdit(selectedCustomer);
            if (editWindow.ShowDialog() == true)
            {
                RefreshCustomerList();
            }
        }

        // delete to the selected customer -window
        private void deleteButton_Click(object sender, RoutedEventArgs e)
        {
            // Get the selected customer from the list
            var selectedCustomer = (Customer)customerListView.SelectedItem;

            if (selectedCustomer != null)
            {
                ObservableCollection<Bill> bills = dbTool.DBSearchCustomerBills(selectedCustomer.CustomerID);

                if (bills.Count == 0)
                {
                    // Confirm that the user really wants to delete the customer
                    var result = MessageBox.Show($"Oletko varma, että haluat poistaa {selectedCustomer.Name}?", "Vahvista poistaminen", MessageBoxButton.YesNo);
                    if (result == MessageBoxResult.Yes)
                    {
                        // Remove the customer from the list
                        dbTool.DBRemoveCustomer(selectedCustomer);

                        // Refresh the customer list
                        RefreshCustomerList();
                    }
                }


                else
                {
                    MessageBox.Show("Et voi poistaa asiakasta, jolla on laskuja järjestelmässä.", "Asiakasta ei voida poistaa");
                }
            }
            else
            {
                MessageBox.Show("Valitse ensin poistettava asiakas.", "Virhe");
                return;
            }
        }

        // refresh listview
        private void RefreshCustomerList()
        {
            var customers = dbTool.DBSearchAllCustomers();
            
            // Update the list view
            customerListView.ItemsSource = customers;
            customerListView.SelectedItem = null;
        }

        // searchbox
        private void searchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            // Get the search text from the search box
            string searchText = searchBox.Text.ToLower();
            //var customers = tool.DBSearchAllCustomers();

            // Filter the customer list view based on the search text
            if (searchText.Length == 0)
            {
                customerListView.ItemsSource = dbTool.DBSearchAllCustomers();
            }
            else
            {
                customerListView.ItemsSource = dbTool.DBSearchAllCustomers().Where(c => c.Name.ToLower().Contains(searchText) ||
                                                                           c.Phone.ToLower().Contains(searchText) ||
                                                                           c.Address.ToLower().Contains(searchText) ||
                                                                           c.Postcode.ToLower().Contains(searchText) ||
                                                                           c.City.ToLower().Contains(searchText));
            }
        }

        // close window
        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
