﻿namespace WpfApp1
{
    public class BillLine
    {
        public int LineID { get; set; }
        public string Name { get; set; }
        public int ServiceID { get; set; }
        public int RoomID { get; set; }
        public int BillID { get; set; }
        public string Unit { get; set; }
        public float UnitPrice { get; set; }
        public int Amount { get; set; }
        public float Sum { get { return Amount * UnitPrice; } }


        public BillLine()
        {
            LineID = -1;
            ServiceID = -1;
            RoomID = -1;
            BillID = -1;
            Unit = string.Empty;
            UnitPrice = 0;
            Name = string.Empty;
            Amount = 0;


        }
        public override string ToString()
        {
            return $"{Name} - ({Unit})    Hinta: {UnitPrice}€    Määrä: {Amount}\n ";
        }
    }


}
   
