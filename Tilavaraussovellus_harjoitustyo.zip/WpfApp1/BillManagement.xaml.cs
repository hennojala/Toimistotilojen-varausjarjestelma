﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography.X509Certificates;
using System.Security.Permissions;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static WpfApp1.MainWindow;

namespace WpfApp1
{

    public partial class BillManagement
    {
        public int Index = -1;       
        public ObservableCollection<Customer> Customers { get; set; } 

        public ObservableCollection<Service> Services { get; set; }
        public ObservableCollection<Room> Rooms { get; set; }
        public ObservableCollection<Room> RoomReservationDates { get; set; }
        public ObservableCollection<Bill> CustomersBills { get; set; }
        public ObservableCollection<Bill> AllBills { get; set; }

        //public ObservableCollection<Bill> Bills { get; set; }
        
        public Customer Customer { get; set; }
        public Room Room { get; set; }

        public Bill Bill { get; set; }
        public BillLine BillLine { get; set; }
        public Repository Repo { get; set; }
        public Service Service { get; set; }
        public float ServiceSum { get; set; }
        public Boolean Update { get; set; }
        public Boolean CreateNew { get; set; }
        public DateTime BillCreted { get; set; }
        public DateTime DueDate { get; set; }
        public DateTime Start { get; set; }
        public DateTime End { get; set; }

        public BillManagement()
        {
            InitializeComponent();

            txtLasku.Focus();

            Bill = new Bill();

            Customer = new Customer();

            CustomersBills = new ObservableCollection<Bill>();

            Services = new ObservableCollection<Service>();

            AllBills = new ObservableCollection<Bill>();

            //Bills = new ObservableCollection<Bill>();
            
            BillLine = new BillLine();

            Repo = new Repository();

            Service = new Service();

            Update = false;

            CreateNew = false;


            BillCreted = new DateTime();
            DueDate = new DateTime();
           

            AlustaKäyttöliittymä();
        }
        public BillManagement(Bill bill)    :this()
        {      
            Bill = bill;

            CreateNew = true;
            
            this.DataContext = Bill;

            AsetaKäyttöliittymä();
            FillCustomerInformation();
            FillRoomInformation();
            UpdateRoomServiceTotalCost();
            UpdateBillSum();
        }
        public BillManagement(Bill bill, Boolean update) : this(bill)
        {
            Update = update;

            CreateNew=false;

            Bill = bill;
            Debug.WriteLine(Bill.RoomID);
            Start = new DateTime();
            End = new DateTime();

            Customers = new ObservableCollection<Customer>();
            Customers = Repo.DBSearchAllCustomers();
            comMuokkaaValitseAsiakas.ItemsSource = Customers;

            Rooms = new ObservableCollection<Room>();
            RoomReservationDates = new ObservableCollection<Room>();
            Rooms = Repo.DBSearchAllRooms();
            comMuokkaaValitseTila.ItemsSource = Rooms;


            Services = Repo.DBGEtRoomsServices(Bill.Room.RoomID);
            comServices.ItemsSource = Services;
           
            txtLasku.Focusable = true;

            dateDueDate.Visibility = Visibility.Visible;   
            dateDueDate.SelectedDate = Bill.DueDate;

            lblBillCreated.Visibility = Visibility.Visible;

            txtLasku.Text = Bill.Description;

            groupMuokkaaValitseTila.Visibility = Visibility.Visible;
            groupMuokkaaValitseAsiakas.Visibility = Visibility.Visible;

            FillRoomInformation();

            UpdateRoomServiceTotalCost();


        }

        //Selaaa laskuja toiminto

        public void AlustaKäyttöliittymä()
        {
            calendar.Focusable = false;
            groupCalendar.Visibility = Visibility.Hidden;
            btnPäivitäVarauksenHinta.Visibility = Visibility.Hidden;


            lblEiPalveluja.Visibility = Visibility.Hidden;
            groupAddService.Visibility = Visibility.Hidden;
            groupMuokkaaValitseTila.Visibility = Visibility.Hidden;
            groupMuokkaaValitseAsiakas.Visibility = Visibility.Hidden;
            groupRemoveService.Visibility = Visibility.Hidden;
            groupValitseLasku.Visibility = Visibility.Visible;
            groupKaikkiLaskut.Visibility = Visibility.Visible;

            lblEräpäivä.Content = DateOnly.FromDateTime(Bill.DueDate).ToString();

            lblBillCreated.Visibility = Visibility.Hidden;

            lblEräpäivä.Visibility = Visibility.Hidden;
            dateDueDate.Visibility = Visibility.Hidden;

            Customers = Repo.DBSearchAllCustomers();
            comValitseAsiakas.ItemsSource = Customers;

            AllBills = Repo.DBSearchAllBills();
            comKaikkiLaskut.ItemsSource = AllBills;


            lblHaeAsiakkaanLaskut.Visibility = Visibility.Hidden;
            comHaeAsiakkaanLasku.Visibility = Visibility.Hidden;

            btnTallennaLasku.Visibility = Visibility.Hidden;    
            btnPoistaLasku.Visibility = Visibility.Hidden;
            btnMuokkaaLaskua.Visibility = Visibility.Hidden;
            btnTulostaLasku.Visibility = Visibility.Hidden;
            btnLähetä.Visibility = Visibility.Hidden;   
        }     
        private void comValitseAsiakas_dropdownClosed(object sender, EventArgs e)
        {
            if (comValitseAsiakas.SelectedIndex != -1)
            {
                comHaeAsiakkaanLasku.SelectedIndex = -1;
                comKaikkiLaskut.SelectedIndex = -1;

                lblHaeAsiakkaanLaskut.Visibility = Visibility.Visible;
                comHaeAsiakkaanLasku.Visibility = Visibility.Visible;

                Customer = Customers[comValitseAsiakas.SelectedIndex];

                CustomersBills = Repo.DBSearchCustomerBills(Customer.CustomerID);
                
                comHaeAsiakkaanLasku.ItemsSource = CustomersBills;

            }
            else
            {
                lblHaeAsiakkaanLaskut.Visibility = Visibility.Hidden;
                comHaeAsiakkaanLasku.Visibility = Visibility.Hidden;

            }

        }
      
        public void comHaeAsiakkaanLaskut_dropDClosed(object sender, EventArgs e)
        {

            if (comHaeAsiakkaanLasku.SelectedIndex != -1)
            {
                comKaikkiLaskut.SelectedIndex = -1;

                Index = comHaeAsiakkaanLasku.SelectedIndex;

                Bill = CustomersBills[Index];

                this.DataContext = Bill;
                UpdateBillDiscription();
                UpdateCustomerInfo();
                FillRoomInformation();
                UpdateRoomServiceTotalCost();

                Services = Repo.DBGEtRoomsServices(Bill.Room.RoomID);
                comServices.ItemsSource = Services;

                btnPoistaLasku.Visibility = Visibility.Visible;
                btnMuokkaaLaskua.Visibility = Visibility.Visible;
                btnTallennaLasku.Visibility = Visibility.Hidden;
                btnTulostaLasku.Visibility = Visibility.Visible;
                btnLähetä.Visibility = Visibility.Visible;

                lblEräpäivä.Visibility = Visibility.Visible;
                lblBillCreated.Visibility = Visibility.Visible;


            }

        }
        public void comKaikkiLaskut_DropDclosed(object sender, EventArgs e)
        {
            if(comKaikkiLaskut.SelectedIndex != -1)
            {
                comValitseAsiakas.SelectedIndex = -1;
                comHaeAsiakkaanLasku.SelectedIndex  = -1;
                Index = comKaikkiLaskut.SelectedIndex;
                Bill = AllBills[Index];
                Debug.WriteLine(Bill.BillLines.Count);
                this.DataContext = Bill;

                Services = Repo.DBGEtRoomsServices(Bill.Room.RoomID);
                comServices.ItemsSource = Services;         

                UpdateBillDiscription();
                UpdateCustomerInfo();
                FillRoomInformation();
                UpdateRoomServiceTotalCost();

                UpdateBillSum();


                btnPoistaLasku.Visibility = Visibility.Visible;
                btnMuokkaaLaskua.Visibility = Visibility.Visible;
                btnTallennaLasku.Visibility = Visibility.Hidden;
                btnTulostaLasku.Visibility = Visibility.Visible;
                btnLähetä.Visibility = Visibility.Visible;

                lblEräpäivä.Visibility = Visibility.Visible;
                lblBillCreated.Visibility = Visibility.Visible;



            }
        }
        private void comMuokkaaValitseAsiakas_DDownClosed(object sender, EventArgs e)
        {
            if (comMuokkaaValitseAsiakas.SelectedIndex != -1)
            {
                var customer = new Customer();
                customer = Customers[comMuokkaaValitseAsiakas.SelectedIndex];
                Bill.CustomerInfo = customer;
                this.DataContext = Bill;
                UpdateCustomerInfo(customer);           
            }
        }

        private void comMuokkaaValitseTila_DDownClosed(object sender, EventArgs e)
        {
            if (comMuokkaaValitseTila.SelectedIndex != -1)
            {
                var update = MessageBox.Show("Haluatko varmasti vaihtaa tilan? Huomioi että laskulta poistuu varausaika sekä mahdolliset palvelut ja tuotteet, sillä ne ovat tilakohtaisia.", "Kysymys", MessageBoxButton.YesNo,
                   MessageBoxImage.Question);
                if (update == MessageBoxResult.Yes)
                {
                    
                    
                    Room = Rooms[comMuokkaaValitseTila.SelectedIndex];
                    Bill.Room =Room;
                    Bill.BillLines.Clear();
                    this.DataContext = Bill;


                    Services = Repo.DBGEtRoomsServices(Bill.Room.RoomID);
                    if (Services.Count == 0)
                    {
                        lblEiPalveluja.Visibility = Visibility.Visible;
                        groupAddService.Visibility = Visibility.Hidden;
                        groupRemoveService.Visibility = Visibility.Hidden;
                        comServices.ItemsSource = Services;


                    }
                    else
                    {
                        lblEiPalveluja.Visibility = Visibility.Hidden;
                        groupAddService.Visibility = Visibility.Visible;
                        groupRemoveService.Visibility = Visibility.Visible;

                        comServices.ItemsSource = Services;

                    }
                   

                    FillRoomInformation();
                    UpdateRoomServiceTotalCost();
                    UpdateBillSum();
                              
                   
                    lblRoomCost.Content = "0";
                }
                else
                {

                    comMuokkaaValitseTila.SelectedIndex = -1;
                }





            }

        }
        public void UpdateCustomerInfo(Customer CustomerInfo)
        {

            lblAsNimi.Content = CustomerInfo.Name;
            lblAsPuhelin.Content = CustomerInfo.Phone;
            lblAsAddress.Content = CustomerInfo.Address;
            lblAsPostcode.Content = CustomerInfo.Postcode;
            lblAsCity.Content = CustomerInfo.City;

        }
        public void UpdateCustomerInfo()
        {

            lblAsNimi.Content = Bill.CustomerInfo.Name;
            lblAsPuhelin.Content = Bill.CustomerInfo.Phone;
            lblAsAddress.Content = Bill.CustomerInfo.Address;
            lblAsPostcode.Content = Bill.CustomerInfo.Postcode;
            lblAsCity.Content = Bill.CustomerInfo.City;

        }
      
        public void UpdateBillDiscription()
        {
            txtLasku.Text = Bill.Description;
            lblBillCreated.Content = Bill.Date.ToString();
            lblEräpäivä.Content = Bill.DueDate.ToString();
 

        }
        public void UpdateRoomServiceTotalCost()
        {


            double days = (Bill.Room.ReservationEnds - Bill.Room.ReservationStarts).TotalDays + 1;
            int daysint = Convert.ToInt32(days);
            float cost = daysint * Bill.Room.PriceForADay;
            Bill.RoomSum = cost;
            
            lblRoomCost.Content = cost.ToString();

            ServiceSum = 0;
            foreach (var line in Bill.BillLines)
            {
                ServiceSum += line.Sum;
            }
            lblSum.Content = ServiceSum.ToString();

            Bill.BillSum = Bill.RoomSum + ServiceSum;

            lblBillSumm.Content = Bill.BillSum.ToString();

        }
        private void btnPoistaLasku_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Haluatko peruuttaa varauksen ja poistaa laskun järjestelmästä?", "Vahvista poisto", MessageBoxButton.YesNo,
            MessageBoxImage.Question);
            if (result == MessageBoxResult.Yes)
            {        
                Repo.DeleteBill(Bill.BillID);

                MessageBox.Show("Lasku poistettu", "Info");
                DialogResult = true;
            }
        }
        private void btnMuokkaaLaskua_click(object sender, RoutedEventArgs e)
        {

            var muokkaa = true;

            Services = Repo.DBGEtRoomsServices(Bill.RoomID);    
            comServices.ItemsSource = Services;

            var billmanagementupdateBill = new BillManagement(Bill, muokkaa);
            var result = billmanagementupdateBill.ShowDialog();
            if (result == true)
            {

                DialogResult = true;
               
            }
            else
            {
                DialogResult = true;
            }

        }
       












        //Suorita varaus toimintoja
        public void AsetaKäyttöliittymä()
        {
            lblEiPalveluja.Visibility = Visibility.Hidden;
            groupAddService.Visibility = Visibility.Visible;
            groupMuokkaaValitseTila.Visibility = Visibility.Hidden;
            groupMuokkaaValitseAsiakas.Visibility = Visibility.Hidden;

            groupRemoveService.Visibility = Visibility.Visible;
            groupKaikkiLaskut.Visibility = Visibility.Hidden;
            groupValitseLasku.Visibility = Visibility.Hidden;
            btnPoistaLasku.Visibility = Visibility.Hidden;
            btnMuokkaaLaskua.Visibility = Visibility.Hidden;
            btnTallennaLasku.Visibility = Visibility.Visible;
            btnTulostaLasku.Visibility = Visibility.Hidden;
            btnLähetä.Visibility = Visibility.Hidden;

            lblBillCreated.Visibility = Visibility.Visible;
            lblEräpäivä.Visibility = Visibility.Hidden;
            dateDueDate.Visibility = Visibility.Visible;

            Services = Repo.DBGEtRoomsServices(Bill.Room.RoomID);
            if (Services.Count == 0)
            {
                lblEiPalveluja.Visibility = Visibility.Visible;
                groupAddService.Visibility = Visibility.Hidden;
                groupRemoveService.Visibility = Visibility.Hidden;
                comServices.ItemsSource = Services;


            }
            else
            {
                lblEiPalveluja.Visibility = Visibility.Hidden;
                groupAddService.Visibility = Visibility.Visible;
                groupRemoveService.Visibility = Visibility.Visible;

                comServices.ItemsSource = Services;

            }



        }
        public void UpdateBillSum()
        {
            var roomcost = float.Parse(lblRoomCost.Content.ToString());

            Bill.BillSum = roomcost + ServiceSum;
            lblBillSumm.Content = Bill.BillSum.ToString();
        }
        public void FillCustomerInformation()
        {
            lblAsNimi.Content = Bill.CustomerInfo.Name;
            lblAsPuhelin.Content = Bill.CustomerInfo.Phone;
            lblAsAddress.Content = Bill.CustomerInfo.Address;
            lblAsPostcode.Content = Bill.CustomerInfo.Postcode;
            lblAsCity.Content = Bill.CustomerInfo.City;

        }
        public void FillRoomInformation()
        {
            float cost = CountRoomPriceForTheReservationPeriod();
            if (Update == true)
            {

                lblRoomCost.Content = cost.ToString();
                lblRoomname.Content = Bill.Room.Roomname;
                lblRoomReservation.Content = $"Aloitus: {Bill.Room.ReservationStarts.ToShortDateString()}\nLopetus: {Bill.Room.ReservationEnds.ToShortDateString()}";
                lblRoomAddress.Content = Bill.Room.Address;
                lblRoomPostcode.Content = Bill.Room.Postcode;
                lblRoomCity.Content = Bill.Room.City;
                lblRoomCost.Content = cost.ToString();
                lblRoomOneDay.Content = Bill.Room.PriceForADay.ToString();


                //Kalenteri

                // Clear any existing blackout dates from the calendar
                calendar.BlackoutDates.Clear();
                // Clear selected dates so there is no conflict when adding blackout dates
                calendar.SelectedDates.Clear();

                // Check if a room has been selected from the combo box
                if (comMuokkaaValitseTila.SelectedIndex != -1)
                {
                    groupCalendar.Visibility = Visibility.Visible;
                    btnPäivitäVarauksenHinta.Visibility = Visibility.Visible;


                    ObservableCollection<DateTime> blackoutDates = new ObservableCollection<DateTime>();
                    RoomReservationDates = Repo.GetRoomReservationStartAndEnd(Bill.Room.RoomID);

                    // Loop over each reservation for the room
                    foreach (var room in RoomReservationDates)
                    {
                        // Add the start date of the reservation to the blackout dates collection
                        blackoutDates.Add(room.ReservationStarts);

                        // Loop over each day in the reservation and add it to the blackout dates collection
                        for (int i = 0; i < (room.ReservationEnds - room.ReservationStarts).TotalDays; i++)
                        {
                            blackoutDates.Add(room.ReservationStarts.AddDays(i + 1));
                        }
                    }

                    // Loop over each blackout date and add it to the calendar's blackout dates collection
                    foreach (var dt in blackoutDates)
                    {
                        calendar.BlackoutDates.Add(new CalendarDateRange(dt));
                    }
                   


                }

            }
            else
            {
                lblRoomCost.Content = cost.ToString();
                lblRoomname.Content = Bill.Room.Roomname;
                lblRoomReservation.Content = $"Aloitus: {Bill.Room.ReservationStarts.ToShortDateString()}\nLopetus: {Bill.Room.ReservationEnds.ToShortDateString()}";
                lblRoomAddress.Content = Bill.Room.Address;
                lblRoomPostcode.Content = Bill.Room.Postcode;
                lblRoomCity.Content = Bill.Room.City;
                lblRoomCost.Content = cost.ToString();
                lblRoomOneDay.Content = Bill.Room.PriceForADay.ToString();


            }


        }
        public float CountRoomPriceForTheReservationPeriod()
        {

            double days = (Bill.Room.ReservationEnds - Bill.Room.ReservationStarts).TotalDays;
            int daysint = Convert.ToInt32(days);
            if (daysint == 0)
            {
                daysint = 1;

            }
            float cost = daysint * Bill.Room.PriceForADay;

            return cost;
        }
        private void Add_To_Bill_click(object sender, RoutedEventArgs e)
        {
            AddAnewBillLine();
            comServices.SelectedIndex = -1;
            lblHowMany.Text = string.Empty;
            lblServiceName.Content = string.Empty;
            lblServiceUnit.Content = string.Empty;
            lblServicePrice.Content = string.Empty;
            



        }
        public void AddAnewBillLine()
        {
            bool määräAnnettu_oikein = false;
            bool ok = int.TryParse(lblHowMany.Text.ToString(), out int määrä);
            if (true)
            {
                määräAnnettu_oikein = true;

            }

            if (comServices.SelectedIndex != -1)
            {
                BillLine = new BillLine();

                if (Bill.BillLines.Count == 0)
                {

                    BillLine.LineID = 1;
                }
                else
                {
                    var latestBillLine = Bill.BillLines.Last();
                    BillLine.LineID = latestBillLine.LineID + 1;
                }
                BillLine.Name = lblServiceName.Content.ToString();
                BillLine.ServiceID = int.Parse(comServices.SelectedValue.ToString());
                BillLine.RoomID = Bill.Room.RoomID;
                BillLine.BillID = Bill.BillID;
                BillLine.Unit = lblServiceUnit.Content.ToString();
                bool flo = float.TryParse(lblServicePrice.Content.ToString(), out float luku);

                if(flo)
                {
                    BillLine.UnitPrice = luku;
                }

                BillLine.Amount = määrä;
                

                ServiceSum += BillLine.Sum;

                lblSum.Content = ServiceSum.ToString();

                UpdateBillSum();

                Bill.BillLines.Add(BillLine);


                this.DataContext = Bill;


            }

            else if (määräAnnettu_oikein == false)
            {
                MessageBox.Show("Väärä syöte", "Error");

            }
            else
            {
                MessageBox.Show("Valitse tuote tai palvelu jonka haluat laskulle", "Tiedote");
            }

        }
        private void comServices_DropdownClosed(object sender, EventArgs e)
        {
            lblHowMany.Text = "1";
            if (comServices.SelectedIndex != -1)
            {
                foreach (var item in Services)
                {
                    if (item.Service_ID.ToString() == comServices.SelectedValue.ToString())
                    {
                        lblServiceName.Content = item.ServiceName;
                        lblServiceUnit.Content = item.Unit;
                        lblServicePrice.Content = item.Price;

                    }
                }
                AddServiceToBill_Button.Focus();
                
            }


        }
        public void Remove_Click(object sender, RoutedEventArgs e)
        {
            bool onNumero = int.TryParse(txtRemove.Text, out int luku);
            bool onNumeroJokaOnLineID = false;
            BillLine = null;
            if (onNumero)
            {
                foreach (var item in Bill.BillLines)
                {
                    if (item.LineID == luku)
                    {
                        BillLine = item;
                        onNumeroJokaOnLineID = true;
                    }



                }
                if (onNumeroJokaOnLineID == false)
                {
                    MessageBox.Show("Syöttämälläsi numerolla ei ole lisäpalvelua/ -tuotetta laskulla.\nTarkista tunnus.", "Virhe");
                }
                else
                {
                    Bill.BillLines.Remove(BillLine);

                    ServiceSum -= BillLine.Sum;

                    lblSum.Content = ServiceSum.ToString();

                    UpdateBillSum();

                    this.DataContext = Bill;

                }

            }

            txtRemove.Text = string.Empty;


        }
        private void txtRemove_KeyDown(object sender, KeyEventArgs e)
        {
            foreach (var item in Bill.BillLines)
            {

                Debug.WriteLine(item.LineID);

            }
            if (e.Key == Key.Enter)
            {
                bool ok = int.TryParse(txtRemove.Text, out int luku);
                if (ok)
                {
                    Remove_Click(sender, e);

                }
                else
                {
                    MessageBox.Show("Syötteesi on virheellinen. Syötä riville lisäpalvelu\ntai tuote jonka haluat poistaa", "Virhe");
                }
            }
        }

        private void gbox_RemoveService_clicked(object sender, MouseButtonEventArgs e)
        {
            txtRemove.Text = string.Empty;
            txtRemove.Focus();
        }
        private void btnLähetä_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Lähettämiselle ei ole toimintoa", "Virhe");
        }
        private void btnTulosta_Click(object sender, RoutedEventArgs e)
        {

            
            if (Update == true || CreateNew == true)
            {
                
                DateTime today = DateTime.Now;
                today = today.Date;
                   
                if (Bill.DueDate > today)
                {
                   
                    if(Update == true && CreateNew == false)
                    {
                        var UpdateResult = MessageBox.Show("Tallennetaanko lasku?", "Kysymys", MessageBoxButton.YesNo,
                            MessageBoxImage.Question);
                        if (UpdateResult == MessageBoxResult.Yes)
                        {
                            Bill = (Bill)this.DataContext;

                            Bill.Description = txtLasku.Text;
                            Bill.DueDate = (DateTime)dateDueDate.SelectedDate;
                            if (comMuokkaaValitseTila.SelectedIndex != -1)
                            {
                                Bill.Room.ReservationStarts = calendar.SelectedDates[0];
                                Bill.Room.ReservationEnds = calendar.SelectedDates[calendar.SelectedDates.Count - 1];

                            }

                            Repo.DBUpdateBill(Bill);
                            MessageBox.Show("Lasku tallennettu");

                            var tulosta = new BillPaper(Bill);
                            tulosta.ShowDialog();
                            DialogResult = true;
                        }

                    }
                    else if(Update == false && CreateNew == true)
                    {

                        var result = MessageBox.Show("Tallennetaanko lasku?", "Kysymys", MessageBoxButton.YesNo,
               MessageBoxImage.Question);
                        if (result == MessageBoxResult.Yes)
                        {
                            Bill = (Bill)this.DataContext;

                            Bill.Description = txtLasku.Text;
                            Bill.DueDate = (DateTime)dateDueDate.SelectedDate;
                            if (comMuokkaaValitseTila.SelectedIndex != -1)
                            {
                                Bill.Room.ReservationStarts = calendar.SelectedDates[0];
                                Bill.Room.ReservationEnds = calendar.SelectedDates[calendar.SelectedDates.Count - 1];

                            }
                          
                            Repo.DBAddBill(Bill);
                            MessageBox.Show("Lasku tallennettu", "Info");
                            DialogResult = true;

                        }
                    }
                    else
                    {
                        MessageBox.Show("virhe", "Virhe");
                    }
                }
                else
                {
                    MessageBox.Show("Laskun eräpäivä ei voi olla tänään tai menneisyydessä");
                }     
            }
          
            else
            {
                var tulosta = new BillPaper(Bill);
                tulosta.ShowDialog();

            }
        }
    
        private void btnTallennaLasku_Click(object sender, RoutedEventArgs e)
        
        {           
            DateTime today = DateTime.Now;
            today = today.Date;
            if (CreateNew == true && Update == false && dateDueDate.SelectedDate < today)
            {
                MessageBox.Show("Eräpäivä ei olla ennen laskun luontipäivää", "Virhe");
                return;
            }
            if (dateDueDate.SelectedDate == null)
            {
                MessageBox.Show("Valitse ensin eräpäivä", "Virhe");
                return;
            }
            if (lblRoomCost.Content == "0")
            {
                MessageBox.Show("Päivitä tilan varausajankohta", "Virhe");
                return;
            }
            

            if(Update == true && CreateNew == false)
            {
                var UpdateResult = MessageBox.Show("Tallennetaanko lasku?", "Kysymys", MessageBoxButton.YesNo,
                    MessageBoxImage.Question);
                if (UpdateResult == MessageBoxResult.Yes)
                {
                    Bill = (Bill)this.DataContext;

                    Bill.Description = txtLasku.Text;
                    Bill.DueDate = (DateTime)dateDueDate.SelectedDate;

                   
                    Debug.WriteLine(Bill.BillID);
                    Repo.DBUpdateBill(Bill);
                    MessageBox.Show("Lasku tallennettu");

                    this.DataContext = Bill;
                    btnMuokkaaLaskua.Visibility = Visibility.Visible;
                    btnTulostaLasku.Visibility = Visibility.Visible;
                    btnPoistaLasku.Visibility = Visibility.Visible;
                    btnLähetä.Visibility = Visibility.Visible;                 

                    this.DialogResult = true;
                }

            }
            else if(CreateNew == true && Update == false )
            {
                var UpdateResult = MessageBox.Show("Tallennetaanko lasku?", "Kysymys", MessageBoxButton.YesNo,
                    MessageBoxImage.Question);
                if (UpdateResult == MessageBoxResult.Yes)
                {
                    if (comMuokkaaValitseTila.SelectedIndex != -1)
                    {
                        Bill.Room.ReservationStarts = calendar.SelectedDates[0];
                        Bill.Room.ReservationEnds = calendar.SelectedDates[calendar.SelectedDates.Count - 1];


                    }
                    Bill.DueDate = (DateTime)dateDueDate.SelectedDate;
                    Bill.Description = txtLasku.Text;
                    Repo.DBAddBill(Bill);
                    MessageBox.Show("Lasku tallennettu");

                    this.DialogResult = true;
                  
                }

            }

            else
            {
                MessageBox.Show("virhe");
            }
         
        }

        //Close Windiw
        private void btnclose(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void PäivitäVarauksenHinta_click(object sender, RoutedEventArgs e)
        {
            if (comMuokkaaValitseTila.SelectedIndex != -1)
            {
                
               

                if(calendar.SelectedDates.Count == 1)
                {
                    Bill.Room.ReservationStarts = calendar.SelectedDates[0];
                    Bill.Room.ReservationEnds = Bill.Room.ReservationStarts;
                }
                else if(calendar.SelectedDates.Count > 1)
                {
                    if (calendar.SelectedDates[calendar.SelectedDates.Count-1] < calendar.SelectedDates[0])
                    {
                        MessageBox.Show("Maalaa päivät vasemmalta oikealle.","Virhe");
                        return;

                    }
                    Bill.Room.ReservationStarts = calendar.SelectedDates[0];
                    Bill.Room.ReservationEnds = calendar.SelectedDates[calendar.SelectedDates.Count - 1];

                }

                FillRoomInformation();

                UpdateRoomServiceTotalCost();

                UpdateBillSum();
            }

           
            
        }
    }
}
