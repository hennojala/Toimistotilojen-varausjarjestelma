﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for AddNewPalvelu.xaml
    /// </summary>
    public partial class ServiceAdd : Window
    {
        public Service Service { get; set; }
        public Repository Repository { get; set; }

        public ObservableCollection<Room> Rooms { get; set; }

        public Room Room { get; set; }
        public ServiceAdd()
        {
            InitializeComponent();

            Service = new Service();
            Room = new Room();



            Repository = new Repository();

            Rooms = new ObservableCollection<Room>();


            Rooms = Repository.DBGetAllRooms();

            combobox.ItemsSource = Rooms;

            btnDeleteLast.Visibility = Visibility.Hidden;


        }

        //event handler for the Service add -button
        private void btnAdd_click(object sender, RoutedEventArgs e)
        {
            var text = txtPrice.Text.Replace(".", ",");
            bool onfloat = float.TryParse(text, out float luku);

            if (txtname.Text == string.Empty || txtUnit.Text == string.Empty)
            {
                MessageBox.Show("Kentät ei voi olla tyhjiä");

            }
            else
            {
                if (onfloat)
                {
                    Service = (Service)this.DataContext;

                    Service.Price = luku;

                    if (Service.Rooms.Count != 0)
                    {
                        foreach (var room in Service.Rooms)
                        {
                            Repository.DBAddService(Service, room.RoomID);
                        }

                        MessageBox.Show($"Lisäpalveu {Service.ServiceName} lisätty järjestelmään!");
                        DialogResult = true;

                    }
                    else
                    {
                        MessageBox.Show("Palvelulla on oltava ainankin yksi huone annettuna");
                    }
                }
                else
                {
                    MessageBox.Show("Tuotteen hinta on syötetty väärin");
                }
            }
        }

        /// <summary>
        /// Button listener for adding a service to the system
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>


        private void combobox_closed(object sender, EventArgs e)
        {

            if (combobox.SelectedIndex != -1)
            {
                Service = (Service)this.DataContext;
                Service.Rooms.Add(Rooms[combobox.SelectedIndex]);
                this.DataContext = Service;

                combobox.SelectedIndex = -1;
                btnDeleteLast.Visibility = Visibility.Visible;
            }

        }

        private void btnDeleteLast_click(object sender, RoutedEventArgs e)
        {
            btnDeleteLast.Visibility = Visibility.Visible;

            if (Service.Rooms.Count != 0)
            {
                Service.Rooms.RemoveAt(Service.Rooms.Count - 1);
                if (Service.Rooms.Count == 0)
                {
                    btnDeleteLast.Visibility = Visibility.Hidden;
                }
                this.DataContext = Service;

            }
        }

        private void btnClose(object sender, RoutedEventArgs e)
        {
            Close();
        }




        // Auxiliary variable for checking whether decimal separator has been used or not
        private bool isDecimalUsed = false;

        /// <summary>
        /// Event listener that prevents user from entering invalid characters and converts the input to a decimal number regardless of using comma or dot as a decimal separator.
        /// </summary>
        /// <param name = "sender" ></ param >
        /// < param name="e"></param>
        private void txtPrice_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Reset decimal usage flag if user inputs a new value
            if (txtPrice.CaretIndex == txtPrice.Text.Length && !string.IsNullOrEmpty(e.Text))
            {
                isDecimalUsed = false;
            }

            // Check that input is a combination of digits, comma or dot
            Regex regex = new Regex("[^0-9.,]+");
            if (regex.IsMatch(e.Text))
            {
                e.Handled = true;
            }
            else if (e.Text == ",")
            {
                // If user enters a comma, replace it with a dot
                e.Handled = true;
                if (!isDecimalUsed)
                {
                    isDecimalUsed = true;
                    txtPrice.Text += ".";
                    txtPrice.CaretIndex = txtPrice.Text.Length;
                }
            }
            else if (e.Text == ".")
            {
                // If user enters a dot, check that it hasn't been used already
                e.Handled = true;
                if (!isDecimalUsed)
                {
                    isDecimalUsed = true;
                    txtPrice.Text += ".";
                    txtPrice.CaretIndex = txtPrice.Text.Length;
                }
            }
            else
            {
                // Check that the input contains only one comma or dot
                string text = txtPrice.Text + e.Text;
                int dotCount = text.Count(c => c == '.');
                int commaCount = text.Count(c => c == ',');
                if (dotCount + commaCount > 1)
                {
                    e.Handled = true;
                }
            }
        }

    }
}
