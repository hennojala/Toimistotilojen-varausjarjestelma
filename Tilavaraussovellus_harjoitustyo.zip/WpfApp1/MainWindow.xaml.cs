﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public Bill Bill;
        public ObservableCollection<Room> Rooms;
        public ObservableCollection<Service> Services;
        public ObservableCollection<Customer> Customers;
        private Repository dbTool;
        public ObservableCollection<Room> roomReservationDates = new ObservableCollection<Room>();


        public MainWindow()
        {
            InitializeComponent();
            Services = new ObservableCollection<Service>();
            Bill = new Bill();
            Customers = new ObservableCollection<Customer>();
            Rooms = new ObservableCollection<Room>();
            roomReservationDates = new ObservableCollection<Room>();

            dbTool = new Repository(); dbTool.CreateDb(); dbTool.CreateTables(); dbTool.CreateInitialData();

            Customers = dbTool.DBSearchAllCustomers();
            comCustomerName.ItemsSource = Customers;
            comCustomerName.SelectionChanged += comCustomerName_SelectionChanged;

            //Keskisarake
            FillRoomInformation();



        }
        private void FillRoomInformation()
        {
            lbNoServices.Visibility = Visibility.Hidden;
            Rooms = dbTool.DBSearchAllRooms();
            comSelectOffice.ItemsSource = Rooms;


        }

        private void comCustomerName_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Check, is anything selected.
            if (comCustomerName.SelectedItem != null)
            {
                // Selecting Customer-object which was selected by combobox.
                var selectedC = (Customer)comCustomerName.SelectedItem;

                // Set Customer-object for customerDataForm box.
                customerDataForm.DataContext = selectedC;

                // Set this customerinfo to new bill.
                Bill.CustomerInfo = selectedC;

            }
        }

        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            // Create a new customer object
            Customer customer = new Customer();

            // Show the customer edit window and set its DataContext to the new customer object
            var addWindow = new CustomerAdd(customer);

            if (addWindow.ShowDialog() == true)
            {
                //Update combobox
                comCustomerName.ItemsSource = dbTool.DBSearchAllCustomers();
                // Set new Customer to object
                Customer newcustomer = dbTool.DBSearchAllCustomers().Last();

                // Set new customer to dataform and to selectedItem and to new bill customerinfo.
                customerDataForm.DataContext = newcustomer;
                comCustomerName.SelectedIndex = comCustomerName.Items.Count - 1;
                Bill.CustomerInfo = newcustomer;
            }
        }

        /// <summary>
        /// This method is called when the selection in the comSelectOffice dropdown menu changes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void comSelectOffice_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (comSelectOffice.SelectedItem != null)
            {
                // Hide the lbNoServices label
                lbNoServices.Visibility = Visibility.Hidden;

                // Set the Room property of the Bill object to the selected room from the Rooms list
                Bill.Room = Rooms[comSelectOffice.SelectedIndex];

                // Retrieve a list of services associated with the selected room from the database
                Services = dbTool.DBGEtRoomsServices(Bill.Room.RoomID);

                // If the list of services is empty, make the lbNoServices label visible
                if (Services.Count == 0)
                {
                    lbNoServices.Content = "Vuokratilalla ei ole valittavissa yhtään \nlisäpalvelua tai -tuotetta.";
                    lbNoServices.Visibility = Visibility.Visible;
                }
                else
                {
                    lbNoServices.Content = "Vuokratilan lisäpalvelu ja -tuote vaihtoehdot: \n\n";
                    foreach (var service in Services)
                    {
                        lbNoServices.Content += "- " + service.ServiceName + "\n";
                    }
                    lbNoServices.Content += "\n\nLisäpalveluiden valintaan pääset jatkamalla varausta.";
                    lbNoServices.Visibility = Visibility.Visible;
                }
            }
        }


        /// <summary>
        /// Close window.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Save_Button_Click(object sender, RoutedEventArgs e)
        {
            if (Bill.CustomerInfo.Firstname == string.Empty)
            {
                MessageBox.Show("Valitse ensin asiakas", "Virhe");

            }
            else if (Bill.Room.RoomID == -1)
            {
                MessageBox.Show("Valitse ensin huone", "Virhe");

            }
            else if (calendar.SelectedDates.Count < 1)
            {
                MessageBox.Show("Valitse varaukselle päivät", "Virhe");
            }
            else
            {
                // Check if any of the selected dates fall within the blackout dates
                bool hasBlackoutDates = false;
                foreach (var date in calendar.SelectedDates)
                {
                    if (calendar.BlackoutDates.Contains(date))
                    {
                        hasBlackoutDates = true;
                        break;
                    }
                }
                // Show an error message if there are blackout dates in the selection
                if (hasBlackoutDates)
                {
                    MessageBox.Show("Yksi tai useampi valituista päivämääristä on jo varattu..", "Virhe");
                    return;
                }
                // Set reservation start and end dates from the calendar
                Bill.Room.ReservationStarts = calendar.SelectedDates[0];
                Bill.Room.ReservationEnds = calendar.SelectedDates[calendar.SelectedDates.Count - 1];
                // If the selection is made in inverse order flip the dates
                if (Bill.Room.ReservationStarts > Bill.Room.ReservationEnds)
                {
                    DateTime temp = Bill.Room.ReservationStarts;
                    Bill.Room.ReservationStarts = Bill.Room.ReservationEnds;
                    Bill.Room.ReservationEnds = temp;
                }
                // Check if the first selected date is in the past
                if (Bill.Room.ReservationStarts < DateTime.Today)
                {
                    MessageBox.Show("Et voi varata menneisyyteen", "Virhe");
                    return;
                }

                var manageBill = new BillManagement(Bill);
                manageBill.ShowDialog();
            }
        }


        private void comSelectOffice_closed(object sender, EventArgs e)
        {
            // Clear any existing blackout dates from the calendar
            calendar.BlackoutDates.Clear();
            // Clear selected dates so there is no conflict when adding blackout dates
            calendar.SelectedDates.Clear();

            // Check if a room has been selected from the combo box
            if (comSelectOffice.SelectedIndex != -1)
            {
                var roomId = comSelectOffice.SelectedValue.ToString();
                var roomIdInt = int.Parse(roomId);
                ObservableCollection<DateTime> blackoutDates = new ObservableCollection<DateTime>();
                roomReservationDates = dbTool.GetRoomReservationStartAndEnd(roomIdInt);

                // Loop over each reservation for the room
                foreach (var room in roomReservationDates)
                {
                    // Add the start date of the reservation to the blackout dates collection
                    blackoutDates.Add(room.ReservationStarts);

                    // Loop over each day in the reservation and add it to the blackout dates collection
                    for (int i = 0; i < (room.ReservationEnds - room.ReservationStarts).TotalDays; i++)
                    {
                        blackoutDates.Add(room.ReservationStarts.AddDays(i + 1));
                    }
                }

                // Loop over each blackout date and add it to the calendar's blackout dates collection
                foreach (var dt in blackoutDates)
                {
                    calendar.BlackoutDates.Add(new CalendarDateRange(dt));
                }
            }
        }

        /// <summary>
        /// This method is a click event handler for service management window
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnServiceManagment_click(object sender, RoutedEventArgs e)
        {
            // Open the service management window
            var serviceW = new ServiceManagement();
            serviceW.ShowDialog();
        }

        /// <summary>
        /// This method is a click event handler for customerregister window
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItem_CustomerRegister_Click(object sender, RoutedEventArgs e)
        {
            // Open the customer management window
            var p = new CustomerManagement() { Owner = this };
            p.Show();
            // If the user clicks "Save" to close the window, update the customer name combo box
            p.Closed += (o, args) =>
            {
                // Update the customer name combo box with all customers in the database
                comCustomerName.ItemsSource = dbTool.DBSearchAllCustomers();
                comCustomerName.SelectedIndex = -1;
            };
        }

        /// <summary>
        /// This method is a click event handler for bill management window
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Bill_Management_click(object sender, RoutedEventArgs e)
        {
            // Open the bill management window
            var billmanagement = new BillManagement();
            billmanagement.ShowDialog();

            // If the user clicks "Save" to close the window, update the room and customer combo boxes
            billmanagement.Closed += (o, args) =>
            {
                comCustomerName.ItemsSource = dbTool.DBSearchAllCustomers();
                FillRoomInformation();
                comSelectOffice.SelectedIndex = -1;
                comCustomerName.SelectedIndex = -1;
                calendar.SelectedDates.Clear();
            };
        }



        private void MenuItem_OfficeManagement_Click(object sender, RoutedEventArgs e)
        {
            // Open the office management window
            var OfficeManagementWindow = new OfficeManagement { Owner = this };
            OfficeManagementWindow.Show();

            // If the user clicks "Save" to close the window, update the room combo box
            OfficeManagementWindow.Closed += (o, args) =>
            {
                // Update the room combo box with all rooms in the database
                FillRoomInformation();
                comSelectOffice.ItemsSource = dbTool.DBGetAllRooms();

                comSelectOffice.SelectedItem = null;
            };
        }


        //Reservation calender management
        private void PäivitäVarauksenHinta_click(object sender, RoutedEventArgs e)
        {

            if (comSelectOffice.SelectedIndex != -1)
            {
                if (calendar.SelectedDates.Count > 0 && calendar.SelectedDates[0] > DateTime.Today)
                {
                    if (calendar.SelectedDates.Count == 1)
                    {
                        Bill.Room.ReservationStarts = calendar.SelectedDates[0];
                        Bill.Room.ReservationEnds = Bill.Room.ReservationStarts;
                    }
                    else
                    {
                        if (calendar.SelectedDates[calendar.SelectedDates.Count - 1] < calendar.SelectedDates[0])
                        {
                            lblRoomCost.Content = "virhe";
                            calendar.SelectedDates.Clear();
                            return;
                        }

                        Bill.Room.ReservationStarts = calendar.SelectedDates[0];
                        Bill.Room.ReservationEnds = calendar.SelectedDates[calendar.SelectedDates.Count - 1];

                    }
                }
                else
                {
                    return;
                }

                double days = (Bill.Room.ReservationEnds - Bill.Room.ReservationStarts).TotalDays + 1;
                int daysint = Convert.ToInt32(days);
                float cost = daysint * Bill.Room.PriceForADay;
                Bill.RoomSum = cost;

                lblRoomCost.Content = cost.ToString();

                btnJatkaVaraukseen.Focus();

            }

        }


        private void calendar_MouseLeave(object sender, MouseEventArgs e)
        {
            if(comSelectOffice.SelectedIndex != -1)
            {
                if (calendar.SelectedDates.Count >= 1)
                {
                    PäivitäVarauksenHinta_click(sender, e);

                }
            }
           
        }

    }
}
