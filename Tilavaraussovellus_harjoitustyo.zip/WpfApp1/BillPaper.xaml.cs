﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for Paperilasku.xaml
    /// </summary>
    public partial class BillPaper : Window
    {
        public Bill Bill { get; set; }
        public float ServiceSum = 0;

        public BillPaper(Bill bill)
        {
            InitializeComponent();

            Bill = bill;

            this.DataContext = Bill;

            ServiceSum = 0;

            var eräpäivä = DateOnly.FromDateTime(Bill.DueDate);
            lblEräpäivä.Content = eräpäivä.ToString();

            UpdateRoomServiceTotalCost();
            UpdateRoomInfo();

            UpdateCustomerInfo();
            LisätietoaLaatikko();

        }

        public void UpdateRoomServiceTotalCost()
        {


            double days = (Bill.Room.ReservationEnds - Bill.Room.ReservationStarts).TotalDays + 1;
            int daysint = Convert.ToInt32(days);
            float cost = daysint * Bill.Room.PriceForADay;
            Bill.RoomSum = cost;

            lblRoomCost.Content = cost.ToString();

            ServiceSum = 0;
            foreach (var line in Bill.BillLines)
            {
                ServiceSum += line.Sum;
            }
            lblSum.Content = ServiceSum.ToString();

            Bill.BillSum = Bill.RoomSum + ServiceSum;

            lblBillSumm.Content = Bill.BillSum.ToString();

        }

        public void UpdateRoomInfo()
        {

            lblRoomname.Content = Bill.Room.Roomname;
            lblRoomAddress.Content = Bill.Room.Address;
            lblRoomPostcode.Content = Bill.Room.Postcode;
            lblRoomCity.Content = Bill.Room.City;
            lblHuonePäivältä.Content = Bill.Room.PriceForADay;
            if (Bill.Room.ReservationStarts < Bill.Room.ReservationEnds)
            {

                lblRoomReservation.Content = $"Aloitus:{Bill.Room.ReservationStarts.ToShortDateString()}\nLopetus:{Bill.Room.ReservationEnds.ToShortDateString()} ";
            }
            else { lblRoomReservation.Content = "Virhe"; }



        }
        public void UpdateCustomerInfo()
        {

            lblAsNimi.Content = Bill.CustomerInfo.Name;
            lblAsPuhelin.Content = Bill.CustomerInfo.Phone;
            lblAsAddress.Content = Bill.CustomerInfo.Address;
            lblAsPostcode.Content = Bill.CustomerInfo.Postcode;
            lblAsCity.Content = Bill.CustomerInfo.City;

        }


        public void LisätietoaLaatikko()
        {
            var lisätietoa = "";
            if (Bill.Description != string.Empty)
            {
                lisätietoa = "LISÄTIEDOT:  " + "\n" + Bill.Description + "\n\n";
              
                txtLasku.Text += lisätietoa;
            }
            if (Bill.BillLines.Count != 0)
            {
                var count = 0;
                var changerow = 0;

                txtLasku.Text += "PALVELUT JA TUOTTEET:\n";
                foreach (var line in Bill.BillLines)
                {

                    count++;
                    changerow++;
                    txtLasku.Text += line.ToString();

                    if (count != Bill.BillLines.Count)
                    {

                        txtLasku.Text += "\n";
                    }
                    else
                    {
                        txtLasku.Text += ".";
                        break;
                    }
                   

                }

            }
            else
            {
                txtLasku.Text+= "Ei palveluja tai tuotteita";
            }

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Ei toimintaa, lisää tulostinasetukset", "Virhe");
        }

    }
}
