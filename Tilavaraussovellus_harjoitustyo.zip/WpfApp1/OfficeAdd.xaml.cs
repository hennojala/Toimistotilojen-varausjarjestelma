﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for OfficeAdd.xaml
    /// </summary>
    public partial class OfficeAdd : Window
    {
        public Room Room { get; set; }
        public Repository Repository { get; set; }
        public OfficeAdd(Room room)
        {
            InitializeComponent();

            Repository = new Repository();
            Room = new Room();

            this.DataContext = new Room();
        }



        // Handle the AddOffice_Click button click
        private void AddOffice_Click(object sender, RoutedEventArgs e)
        {


            bool onfloat = float.TryParse(txtPrice.Text.Replace(".", ","), out float num);


            try
            {

                int code;
                float flo;
                string patternName = @"^[a-zA-ZäöüÄÖÜÅå\s\-]+$";
                string patternAddressName = @"^[a-zA-ZäöüÄÖÜÅå\0-9\s\-\.,\/\\]+$";


                // Check that all row haves content.
                if (string.IsNullOrWhiteSpace(txtRoomName.Text) ||
                    string.IsNullOrWhiteSpace(txtAddress.Text) ||
                    string.IsNullOrWhiteSpace(txtPostCode.Text) ||
                    string.IsNullOrWhiteSpace(txtCity.Text) ||
                    string.IsNullOrWhiteSpace(txtPrice.Text) ||
                    string.IsNullOrWhiteSpace(txtRoomSize.Text))
                {
                    throw new ArgumentException("Kaikkia kenttiä ei ole täytetty.");
                }

                // Check if the postcode textbox contains only numbers            
                if (!int.TryParse(txtRoomSize.Text, out code))
                {
                    MessageBox.Show("Pinta-ala voi sisältää vain numeroita.", "Virhe");
                    return;
                }

                // Check if the postcode textbox contains only numbers            
                if (!int.TryParse(txtPostCode.Text, out code))
                {
                    MessageBox.Show("Postinumero voi sisältää vain numeroita.", "Virhe");
                    return;
                }

                // Check if the input matches the pattern
                if (!Regex.IsMatch(txtCity.Text, patternName))
                {
                    MessageBox.Show("Paikkakunnalle sallitut merkit ovat kirjaimet, välilyönnit, ääkköset, väliviivat ja Å-merkki.", "Virhe");
                    return;
                }

                // Check if the input matches the pattern
                if (!Regex.IsMatch(txtRoomName.Text, patternAddressName))
                {
                    MessageBox.Show("Nimelle sallitut merkit ovat kirjaimet, välilyönnit, ääkköset, väliviivat ja Å-merkki.", "Virhe");
                    return;
                }

                // Check if the input matches the pattern
                if (!Regex.IsMatch(txtAddress.Text, patternAddressName))
                {
                    MessageBox.Show("Osoite voi sisältää vain kirjaimia, numeroita ja joitain tyypillisiä erikoismerkkejä", "Virhe");
                    return;
                }


                if (onfloat)
                {
                    Room = (Room)this.DataContext;
                    Room.PriceForADay = num;


                    // Add the room to the database
                    Repository.DBAddRoom(Room);

                    // Clear the textboxes
                    txtRoomName.Text = "";
                    txtAddress.Text = "";
                    txtPostCode.Text = "";
                    txtCity.Text = "";
                    txtRoomSize.Text = "";
                    txtPrice.Text = "";

                    DialogResult = true;
                }

                else
                {
                    MessageBox.Show("Tuotteen hinta on syötetty väärin", "Virhe");
                }

            }

            catch (ArgumentException ex)
            {
                // If an ArgumentException is thrown, show an error message
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                // If any other exception is thrown, show a general error message
                MessageBox.Show("Virhe lisättäessä huonetta tietokantaan: " + ex.Message);
            }
        }

        // Auxiliary variable for checking whether decimal separator has been used or not
        private bool isDecimalUsed = false;

        /// <summary>
        /// Event listener that prevents user from entering invalid characters and converts the input to a decimal number regardless of using comma or dot as a decimal separator.
        /// </summary>
        /// <param name = "sender" ></ param >
        /// < param name="e"></param>
        private void txtPrice_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {

            // Reset decimal usage flag if user inputs a new value
            if (txtPrice.CaretIndex == txtPrice.Text.Length && !string.IsNullOrEmpty(e.Text))
            {
                isDecimalUsed = false;
            }

            // Check that input is a combination of digits, comma or dot
            Regex regex = new Regex("[^0-9.,]+");
            if (regex.IsMatch(e.Text))
            {
                e.Handled = true;
            }
            else if (e.Text == ",")
            {
                // If user enters a comma, replace it with a dot
                e.Handled = true;
                if (!isDecimalUsed)
                {
                    isDecimalUsed = true;
                    txtPrice.Text += ".";
                    txtPrice.CaretIndex = txtPrice.Text.Length;
                }
            }
            else if (e.Text == ".")
            {
                // If user enters a dot, check that it hasn't been used already
                e.Handled = true;
                if (!isDecimalUsed)
                {
                    isDecimalUsed = true;
                    txtPrice.Text += ".";
                    txtPrice.CaretIndex = txtPrice.Text.Length;
                }
            }
            else
            {
                // Check that the input contains only one comma or dot
                string text = txtPrice.Text + e.Text;
                int dotCount = text.Count(c => c == '.');
                int commaCount = text.Count(c => c == ',');
                if (dotCount + commaCount > 1)
                {
                    e.Handled = true;
                }
            }
        }

        /// <summary>
        /// Close window.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void closeButtonClick(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
